export declare const TODAS_AREAS_GERENCIAIS: {
    nome: string;
    subareas: {
        nome: string;
        praticas: {
            n: number;
            t: string;
            c: string;
        }[];
    }[];
}[];
export declare function extrairPraticasComDados(org: any, area: any): any;
//# sourceMappingURL=todasAreasDefinicoes.d.ts.map