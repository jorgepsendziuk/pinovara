import { AreaGerencial } from './praticasDefinicoes';
export { GOVERNANCA_ORGANIZACIONAL, GESTAO_PESSOAS } from './praticasDefinicoes';
export declare const GESTAO_FINANCEIRA: AreaGerencial;
export type OrganizacaoData = any;
//# sourceMappingURL=todasAreas.d.ts.map