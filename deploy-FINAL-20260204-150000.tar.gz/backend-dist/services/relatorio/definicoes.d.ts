export declare const TODAS_AREAS: {
    nome: string;
    sub: {
        nome: string;
        p: {
            n: number;
            t: string;
            c: string;
        }[];
    }[];
}[];
export declare function renderizarTodasAreasGerenciais(doc: any, org: any): void;
//# sourceMappingURL=definicoes.d.ts.map