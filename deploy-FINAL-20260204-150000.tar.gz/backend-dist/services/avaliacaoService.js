"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const api_1 = require("../types/api");
const ApiError_1 = require("../utils/ApiError");
const prisma = new client_1.PrismaClient();
class AvaliacaoService {
    async listVersoes(ativo) {
        const where = {};
        if (ativo !== undefined) {
            where.ativo = ativo;
        }
        const versoes = await prisma.avaliacao_versao.findMany({
            where,
            include: {
                avaliacao_pergunta: {
                    orderBy: { ordem: 'asc' }
                }
            },
            orderBy: { created_at: 'desc' }
        });
        return versoes.map(v => {
            const perguntasParsed = v.avaliacao_pergunta.map(p => {
                let opcoesParsed;
                try {
                    opcoesParsed = p.opcoes ? JSON.parse(p.opcoes) : undefined;
                }
                catch {
                    opcoesParsed = p.opcoes ? [p.opcoes] : undefined;
                }
                return {
                    ...p,
                    opcoes: opcoesParsed
                };
            });
            return {
                ...v,
                perguntas: perguntasParsed
            };
        });
    }
    async getVersaoAtiva() {
        const versao = await prisma.avaliacao_versao.findFirst({
            where: { ativo: true },
            include: {
                avaliacao_pergunta: {
                    orderBy: { ordem: 'asc' }
                }
            },
            orderBy: { created_at: 'desc' }
        });
        if (!versao) {
            return null;
        }
        const perguntasParsed = versao.avaliacao_pergunta.map(p => {
            let opcoesParsed;
            try {
                opcoesParsed = p.opcoes ? JSON.parse(p.opcoes) : undefined;
            }
            catch {
                opcoesParsed = p.opcoes ? [p.opcoes] : undefined;
            }
            return {
                ...p,
                opcoes: opcoesParsed
            };
        });
        return {
            ...versao,
            perguntas: perguntasParsed
        };
    }
    async getVersaoById(id) {
        const versao = await prisma.avaliacao_versao.findUnique({
            where: { id },
            include: {
                avaliacao_pergunta: {
                    orderBy: { ordem: 'asc' }
                }
            }
        });
        if (!versao) {
            return null;
        }
        const perguntasParsed = versao.avaliacao_pergunta.map(p => {
            let opcoesParsed;
            try {
                opcoesParsed = p.opcoes ? JSON.parse(p.opcoes) : undefined;
            }
            catch {
                opcoesParsed = p.opcoes ? [p.opcoes] : undefined;
            }
            return {
                ...p,
                opcoes: opcoesParsed
            };
        });
        return {
            ...versao,
            perguntas: perguntasParsed
        };
    }
    async createVersao(data, userId) {
        const existing = await prisma.avaliacao_versao.findUnique({
            where: { versao: data.versao }
        });
        if (existing) {
            throw new ApiError_1.ApiError({
                message: 'Versão já existe',
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.RESOURCE_ALREADY_EXISTS
            });
        }
        if (data.ativo) {
            await prisma.avaliacao_versao.updateMany({
                where: { ativo: true },
                data: { ativo: false }
            });
        }
        const versao = await prisma.avaliacao_versao.create({
            data: {
                versao: data.versao,
                descricao: data.descricao,
                ativo: data.ativo !== undefined ? data.ativo : false,
                created_by: userId
            }
        });
        if (data.perguntas && data.perguntas.length > 0) {
            await prisma.avaliacao_pergunta.createMany({
                data: data.perguntas.map(p => ({
                    id_versao: versao.id,
                    ordem: p.ordem,
                    texto_pergunta: p.texto_pergunta,
                    tipo: p.tipo,
                    opcoes: p.opcoes ? JSON.stringify(p.opcoes) : null,
                    obrigatoria: p.obrigatoria !== undefined ? p.obrigatoria : true
                }))
            });
        }
        return this.getVersaoById(versao.id);
    }
    async updateVersao(id, data, userId) {
        const existing = await prisma.avaliacao_versao.findUnique({
            where: { id }
        });
        if (!existing) {
            throw new ApiError_1.ApiError({
                message: 'Versão não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        if (data.ativo === true) {
            await prisma.avaliacao_versao.updateMany({
                where: {
                    ativo: true,
                    id: { not: id }
                },
                data: { ativo: false }
            });
        }
        const updated = await prisma.avaliacao_versao.update({
            where: { id },
            data: {
                ...(data.descricao !== undefined && { descricao: data.descricao }),
                ...(data.ativo !== undefined && { ativo: data.ativo }),
                updated_at: new Date()
            }
        });
        return this.getVersaoById(id);
    }
    async listPerguntas(idVersao) {
        const perguntas = await prisma.avaliacao_pergunta.findMany({
            where: { id_versao: idVersao },
            orderBy: { ordem: 'asc' }
        });
        return perguntas.map(p => {
            let opcoesParsed;
            try {
                opcoesParsed = p.opcoes ? JSON.parse(p.opcoes) : undefined;
            }
            catch {
                opcoesParsed = p.opcoes ? [p.opcoes] : undefined;
            }
            return {
                ...p,
                opcoes: opcoesParsed
            };
        });
    }
    async createPergunta(idVersao, data) {
        const versao = await prisma.avaliacao_versao.findUnique({
            where: { id: idVersao }
        });
        if (!versao) {
            throw new ApiError_1.ApiError({
                message: 'Versão não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const pergunta = await prisma.avaliacao_pergunta.create({
            data: {
                id_versao: idVersao,
                ordem: data.ordem,
                texto_pergunta: data.texto_pergunta,
                tipo: data.tipo,
                opcoes: data.opcoes ? JSON.stringify(data.opcoes) : null,
                obrigatoria: data.obrigatoria !== undefined ? data.obrigatoria : true
            }
        });
        let opcoesParsed;
        try {
            opcoesParsed = pergunta.opcoes ? JSON.parse(pergunta.opcoes) : undefined;
        }
        catch {
            opcoesParsed = pergunta.opcoes ? [pergunta.opcoes] : undefined;
        }
        return {
            ...pergunta,
            opcoes: opcoesParsed
        };
    }
    async updatePergunta(id, data) {
        const existing = await prisma.avaliacao_pergunta.findUnique({
            where: { id }
        });
        if (!existing) {
            throw new ApiError_1.ApiError({
                message: 'Pergunta não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const updated = await prisma.avaliacao_pergunta.update({
            where: { id },
            data: {
                ...(data.ordem !== undefined && { ordem: data.ordem }),
                ...(data.texto_pergunta !== undefined && { texto_pergunta: data.texto_pergunta }),
                ...(data.tipo !== undefined && { tipo: data.tipo }),
                ...(data.opcoes !== undefined && { opcoes: data.opcoes ? JSON.stringify(data.opcoes) : null }),
                ...(data.obrigatoria !== undefined && { obrigatoria: data.obrigatoria })
            }
        });
        let opcoesParsed;
        try {
            opcoesParsed = updated.opcoes ? JSON.parse(updated.opcoes) : undefined;
        }
        catch {
            opcoesParsed = updated.opcoes ? [updated.opcoes] : undefined;
        }
        return {
            ...updated,
            opcoes: opcoesParsed
        };
    }
    async deletePergunta(id) {
        const existing = await prisma.avaliacao_pergunta.findUnique({
            where: { id }
        });
        if (!existing) {
            throw new ApiError_1.ApiError({
                message: 'Pergunta não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        await prisma.avaliacao_pergunta.delete({
            where: { id }
        });
    }
    async createAvaliacao(idCapacitacao, data, idInscricao) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { id: idCapacitacao }
        });
        if (!capacitacao) {
            throw new ApiError_1.ApiError({
                message: 'Capacitação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const versaoAtiva = await this.getVersaoAtiva();
        if (!versaoAtiva) {
            throw new ApiError_1.ApiError({
                message: 'Nenhuma versão de avaliação ativa encontrada',
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.RESOURCE_CONFLICT
            });
        }
        if (idInscricao) {
            const inscricao = await prisma.capacitacao_inscricao.findUnique({
                where: { id: idInscricao }
            });
            if (!inscricao || inscricao.id_capacitacao !== idCapacitacao) {
                throw new ApiError_1.ApiError({
                    message: 'Inscrição não encontrada ou não pertence a esta capacitação',
                    statusCode: api_1.HttpStatus.NOT_FOUND,
                    code: api_1.ErrorCode.RESOURCE_NOT_FOUND
                });
            }
        }
        const perguntasObrigatorias = await prisma.avaliacao_pergunta.findMany({
            where: {
                id_versao: versaoAtiva.id,
                obrigatoria: true
            }
        });
        const perguntasRespondidas = new Set(data.respostas.map(r => r.id_pergunta));
        const perguntasFaltantes = perguntasObrigatorias.filter(p => !perguntasRespondidas.has(p.id));
        if (perguntasFaltantes.length > 0) {
            throw new ApiError_1.ApiError({
                message: `Perguntas obrigatórias não respondidas: ${perguntasFaltantes.map(p => p.texto_pergunta).join(', ')}`,
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.MISSING_REQUIRED_FIELD
            });
        }
        const avaliacao = await prisma.capacitacao_avaliacao.create({
            data: {
                id_capacitacao: idCapacitacao,
                id_versao_avaliacao: versaoAtiva.id,
                id_inscricao: idInscricao || null,
                nome_participante: data.nome_participante?.trim() || null,
                email_participante: data.email_participante?.trim() || null,
                telefone_participante: data.telefone_participante?.trim() || null,
                comentarios: data.comentarios?.trim() || null
            }
        });
        if (data.respostas && data.respostas.length > 0) {
            await prisma.capacitacao_avaliacao_resposta.createMany({
                data: data.respostas.map(r => ({
                    id_avaliacao: avaliacao.id,
                    id_pergunta: r.id_pergunta,
                    resposta_texto: r.resposta_texto?.trim() || null,
                    resposta_opcao: r.resposta_opcao?.trim() || null
                })),
                skipDuplicates: true
            });
        }
        return this.getAvaliacaoById(avaliacao.id);
    }
    async getAvaliacaoById(id) {
        const avaliacao = await prisma.capacitacao_avaliacao.findUnique({
            where: { id },
            include: {
                capacitacao_avaliacao_resposta: {
                    include: {
                        avaliacao_pergunta: true
                    }
                }
            }
        });
        if (!avaliacao) {
            return null;
        }
        return {
            ...avaliacao,
            respostas: avaliacao.capacitacao_avaliacao_resposta.map(r => ({
                ...r,
                pergunta: r.avaliacao_pergunta
            }))
        };
    }
    async listAvaliacoes(idCapacitacao) {
        const avaliacoes = await prisma.capacitacao_avaliacao.findMany({
            where: { id_capacitacao: idCapacitacao },
            include: {
                capacitacao_avaliacao_resposta: {
                    include: {
                        avaliacao_pergunta: true
                    }
                }
            },
            orderBy: { created_at: 'desc' }
        });
        return avaliacoes.map(a => ({
            ...a,
            respostas: a.capacitacao_avaliacao_resposta.map(r => ({
                ...r,
                pergunta: r.avaliacao_pergunta
            }))
        }));
    }
    async getEstatisticas(idCapacitacao) {
        const avaliacoes = await this.listAvaliacoes(idCapacitacao);
        if (avaliacoes.length === 0) {
            return [];
        }
        const versaoAtiva = await this.getVersaoAtiva();
        if (!versaoAtiva || !versaoAtiva.perguntas) {
            return [];
        }
        const estatisticas = [];
        for (const pergunta of versaoAtiva.perguntas) {
            const respostas = avaliacoes
                .flatMap(a => a.respostas || [])
                .filter(r => r.id_pergunta === pergunta.id);
            const total_respostas = respostas.length;
            let distribuicao;
            let media;
            if (pergunta.tipo === 'escala_5' || pergunta.tipo === 'escala_3') {
                const valores = [];
                distribuicao = {};
                for (const resposta of respostas) {
                    const valor = resposta.resposta_opcao;
                    if (valor) {
                        const num = parseInt(valor);
                        if (!isNaN(num)) {
                            valores.push(num);
                            distribuicao[valor] = (distribuicao[valor] || 0) + 1;
                        }
                    }
                }
                if (valores.length > 0) {
                    media = valores.reduce((a, b) => a + b, 0) / valores.length;
                }
            }
            else if (pergunta.tipo !== 'texto_livre') {
                distribuicao = {};
                for (const resposta of respostas) {
                    const opcao = resposta.resposta_opcao || 'sem_resposta';
                    distribuicao[opcao] = (distribuicao[opcao] || 0) + 1;
                }
            }
            estatisticas.push({
                pergunta: {
                    id: pergunta.id,
                    texto: pergunta.texto_pergunta,
                    tipo: pergunta.tipo
                },
                total_respostas,
                distribuicao,
                media
            });
        }
        return estatisticas;
    }
}
exports.default = new AvaliacaoService();
//# sourceMappingURL=avaliacaoService.js.map