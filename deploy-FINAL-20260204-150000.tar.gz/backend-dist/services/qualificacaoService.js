"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const api_1 = require("../types/api");
const ApiError_1 = require("../utils/ApiError");
const prisma = new client_1.PrismaClient();
class QualificacaoService {
    async list(filters = {}) {
        const { page = 1, limit = 10, titulo, ativo, id_organizacao, id_instrutor, created_by } = filters;
        const filterByUser = filters.filterByUser;
        const userId = filters.userId;
        const whereConditions = {};
        if (titulo) {
            whereConditions.titulo = {
                contains: titulo,
                mode: 'insensitive'
            };
        }
        if (ativo !== undefined) {
            whereConditions.ativo = ativo;
        }
        if (filterByUser && userId) {
            let idsCompartilhadas = [];
            try {
                const qualificacoesCompartilhadas = await prisma.qualificacao_tecnico.findMany({
                    where: { id_tecnico: userId },
                    select: { id_qualificacao: true }
                });
                idsCompartilhadas = qualificacoesCompartilhadas.map(qt => qt.id_qualificacao);
            }
            catch (error) {
                console.warn('Tabela qualificacao_tecnico ainda não existe ou erro ao buscar compartilhamentos:', error.message);
            }
            whereConditions.OR = [
                { created_by: userId },
                { id: { in: [1, 2, 3] } },
                ...(idsCompartilhadas.length > 0 ? [{ id: { in: idsCompartilhadas } }] : [])
            ];
        }
        else if (created_by) {
            whereConditions.created_by = created_by;
        }
        if (id_organizacao) {
            whereConditions.qualificacao_organizacao = {
                some: {
                    id_organizacao: id_organizacao
                }
            };
        }
        if (id_instrutor) {
            whereConditions.qualificacao_instrutor = {
                some: {
                    id_instrutor: id_instrutor
                }
            };
        }
        const skip = (page - 1) * limit;
        const [qualificacoes, total] = await Promise.all([
            prisma.qualificacao.findMany({
                where: whereConditions,
                skip,
                take: limit,
                orderBy: { id: 'desc' },
                include: {
                    qualificacao_organizacao: {
                        select: {
                            id_organizacao: true
                        }
                    },
                    qualificacao_instrutor: {
                        select: {
                            id_instrutor: true
                        }
                    },
                    qualificacao_tecnico: {
                        select: {
                            id_tecnico: true,
                            tecnico: {
                                select: {
                                    id: true,
                                    name: true,
                                    email: true
                                }
                            }
                        }
                    },
                    created_by_user: {
                        select: {
                            id: true,
                            name: true,
                            email: true,
                        },
                    },
                }
            }),
            prisma.qualificacao.count({ where: whereConditions })
        ]);
        const criadoresIds = qualificacoes
            .filter(q => q.created_by)
            .map(q => q.created_by)
            .filter((id, index, self) => self.indexOf(id) === index);
        const criadores = criadoresIds.length > 0 ? await prisma.users.findMany({
            where: {
                id: { in: criadoresIds }
            },
            select: {
                id: true,
                name: true,
                email: true
            }
        }) : [];
        const formattedQualificacoes = qualificacoes.map(q => {
            const criador = q.created_by_user || (q.created_by ? criadores.find(cr => cr.id === q.created_by) : null);
            return {
                ...q,
                organizacoes: q.qualificacao_organizacao.map(ro => ro.id_organizacao),
                instrutores: q.qualificacao_instrutor.map(ri => ri.id_instrutor),
                equipe_tecnica: (q.qualificacao_tecnico || []).map(qt => ({
                    id_tecnico: qt.id_tecnico,
                    tecnico: qt.tecnico
                })),
                criador: criador ? {
                    id: criador.id,
                    name: criador.name,
                    email: criador.email
                } : null
            };
        });
        return {
            qualificacoes: formattedQualificacoes,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit)
        };
    }
    async getById(id) {
        const qualificacao = await prisma.qualificacao.findUnique({
            where: { id },
            include: {
                qualificacao_organizacao: {
                    select: {
                        id_organizacao: true
                    }
                },
                qualificacao_instrutor: {
                    select: {
                        id_instrutor: true
                    }
                },
                qualificacao_tecnico: {
                    select: {
                        id_tecnico: true,
                        tecnico: {
                            select: {
                                id: true,
                                name: true,
                                email: true
                            }
                        }
                    }
                },
                created_by_user: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                },
                validacao_usuario_user: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                },
            }
        });
        if (!qualificacao) {
            return null;
        }
        return {
            ...qualificacao,
            organizacoes: qualificacao.qualificacao_organizacao.map(ro => ro.id_organizacao),
            instrutores: qualificacao.qualificacao_instrutor.map(ri => ri.id_instrutor),
            equipe_tecnica: qualificacao.qualificacao_tecnico.map(qt => ({
                id_tecnico: qt.id_tecnico,
                tecnico: qt.tecnico
            })),
            criador: qualificacao.created_by_user ? {
                id: qualificacao.created_by_user.id,
                name: qualificacao.created_by_user.name,
                email: qualificacao.created_by_user.email
            } : null,
            validacao_usuario_nome: qualificacao.validacao_usuario_user?.name || null
        };
    }
    async create(data, userId) {
        const { organizacoes, instrutores, ...qualificacaoData } = data;
        if (!data.titulo || data.titulo.trim().length === 0) {
            throw new ApiError_1.ApiError({
                message: 'Título da qualificação é obrigatório',
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.MISSING_REQUIRED_FIELD
            });
        }
        const qualificacao = await prisma.qualificacao.create({
            data: {
                ...qualificacaoData,
                titulo: qualificacaoData.titulo.trim(),
                created_by: userId,
                ativo: qualificacaoData.ativo !== undefined ? qualificacaoData.ativo : true
            }
        });
        if (organizacoes && organizacoes.length > 0) {
            await prisma.qualificacao_organizacao.createMany({
                data: organizacoes.map((id_organizacao) => ({
                    id_qualificacao: qualificacao.id,
                    id_organizacao
                })),
                skipDuplicates: true
            });
        }
        if (instrutores && instrutores.length > 0) {
            await prisma.qualificacao_instrutor.createMany({
                data: instrutores.map((id_instrutor) => ({
                    id_qualificacao: qualificacao.id,
                    id_instrutor
                })),
                skipDuplicates: true
            });
        }
        return this.getById(qualificacao.id);
    }
    async update(id, data, userId) {
        const existing = await prisma.qualificacao.findUnique({
            where: { id }
        });
        if (!existing) {
            throw new ApiError_1.ApiError({
                message: 'Qualificação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const { organizacoes, instrutores, ...qualificacaoData } = data;
        const updateData = {
            ...(qualificacaoData.titulo && { titulo: qualificacaoData.titulo.trim() }),
            ...(qualificacaoData.objetivo_geral !== undefined && { objetivo_geral: qualificacaoData.objetivo_geral }),
            ...(qualificacaoData.objetivos_especificos !== undefined && { objetivos_especificos: qualificacaoData.objetivos_especificos }),
            ...(qualificacaoData.conteudo_programatico !== undefined && { conteudo_programatico: qualificacaoData.conteudo_programatico }),
            ...(qualificacaoData.metodologia !== undefined && { metodologia: qualificacaoData.metodologia }),
            ...(qualificacaoData.recursos_didaticos !== undefined && { recursos_didaticos: qualificacaoData.recursos_didaticos }),
            ...(qualificacaoData.estrategia_avaliacao !== undefined && { estrategia_avaliacao: qualificacaoData.estrategia_avaliacao }),
            ...(qualificacaoData.referencias !== undefined && { referencias: qualificacaoData.referencias }),
            ...(qualificacaoData.ativo !== undefined && { ativo: qualificacaoData.ativo }),
            updated_at: new Date()
        };
        const updated = await prisma.qualificacao.update({
            where: { id },
            data: updateData
        });
        if (organizacoes !== undefined) {
            await prisma.qualificacao_organizacao.deleteMany({
                where: { id_qualificacao: id }
            });
            if (organizacoes.length > 0) {
                await prisma.qualificacao_organizacao.createMany({
                    data: organizacoes.map((id_organizacao) => ({
                        id_qualificacao: id,
                        id_organizacao
                    })),
                    skipDuplicates: true
                });
            }
        }
        if (instrutores !== undefined) {
            await prisma.qualificacao_instrutor.deleteMany({
                where: { id_qualificacao: id }
            });
            if (instrutores.length > 0) {
                await prisma.qualificacao_instrutor.createMany({
                    data: instrutores.map((id_instrutor) => ({
                        id_qualificacao: id,
                        id_instrutor
                    })),
                    skipDuplicates: true
                });
            }
        }
        return this.getById(id);
    }
    async addTecnico(idQualificacao, idTecnico, userId) {
        const qualificacao = await prisma.qualificacao.findUnique({
            where: { id: idQualificacao }
        });
        if (!qualificacao) {
            throw new Error('Qualificação não encontrada');
        }
        const existing = await prisma.qualificacao_tecnico.findUnique({
            where: {
                id_qualificacao_id_tecnico: {
                    id_qualificacao: idQualificacao,
                    id_tecnico: idTecnico
                }
            }
        });
        if (existing) {
            throw new Error('Técnico já está na equipe desta qualificação');
        }
        await prisma.qualificacao_tecnico.create({
            data: {
                id_qualificacao: idQualificacao,
                id_tecnico: idTecnico,
                created_by: userId
            }
        });
    }
    async removeTecnico(idQualificacao, idTecnico) {
        await prisma.qualificacao_tecnico.delete({
            where: {
                id_qualificacao_id_tecnico: {
                    id_qualificacao: idQualificacao,
                    id_tecnico: idTecnico
                }
            }
        });
    }
    async listTecnicos(idQualificacao) {
        const tecnicos = await prisma.qualificacao_tecnico.findMany({
            where: { id_qualificacao: idQualificacao },
            include: {
                tecnico: {
                    select: {
                        id: true,
                        name: true,
                        email: true
                    }
                }
            }
        });
        return tecnicos.map(t => ({
            id_tecnico: t.id_tecnico,
            tecnico: t.tecnico
        }));
    }
    async delete(id) {
        const existing = await prisma.qualificacao.findUnique({
            where: { id },
            include: {
                capacitacao: {
                    take: 1
                }
            }
        });
        if (!existing) {
            throw new ApiError_1.ApiError({
                message: 'Qualificação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        if (existing.capacitacao && existing.capacitacao.length > 0) {
            throw new ApiError_1.ApiError({
                message: 'Não é possível excluir qualificação com capacitações vinculadas',
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.RESOURCE_CONFLICT
            });
        }
        await prisma.qualificacao.delete({
            where: { id }
        });
    }
    async listTecnicosDisponiveis() {
        const tecnicos = await prisma.users.findMany({
            where: {
                active: true,
                user_roles: {
                    some: {
                        roles: {
                            name: 'tecnico',
                            modules: {
                                name: 'organizacoes'
                            }
                        }
                    }
                }
            },
            select: {
                id: true,
                name: true,
                email: true
            },
            orderBy: {
                name: 'asc'
            }
        });
        return tecnicos;
    }
    async updateValidacao(id, dadosValidacao) {
        const existingQualificacao = await prisma.qualificacao.findUnique({
            where: { id }
        });
        if (!existingQualificacao) {
            throw new ApiError_1.ApiError({
                message: 'Qualificação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const qualificacao = await prisma.qualificacao.update({
            where: { id },
            data: {
                validacao_status: dadosValidacao.validacao_status,
                validacao_obs: dadosValidacao.validacao_obs,
                validacao_usuario: dadosValidacao.validacao_usuario,
                validacao_data: dadosValidacao.validacao_data
            }
        });
        return qualificacao;
    }
    async getHistoricoValidacao(idQualificacao) {
        const qualificacao = await prisma.qualificacao.findUnique({
            where: { id: idQualificacao },
            select: { id: true, titulo: true }
        });
        if (!qualificacao) {
            throw new ApiError_1.ApiError({
                message: 'Qualificação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const sqlQuery = `
      SELECT 
        al.id AS log_id,
        al."entityId"::integer AS qualificacao_id,
        al.action,
        al."createdAt" AS data_mudanca,
        al."userId",
        u.name AS usuario_nome,
        u.email AS usuario_email,
        al."oldData",
        al."newData"
      FROM pinovara.audit_logs al
      LEFT JOIN pinovara.users u ON al."userId" = u.id
      WHERE al.entity = 'qualificacao' 
        AND al."entityId"::integer = ${idQualificacao}
        AND (
          al.action LIKE '%validacao%' 
          OR al.action LIKE '%validation%' 
          OR al."newData"::text LIKE '%validacao_status%'
          OR al."oldData"::text LIKE '%validacao_status%'
        )
      ORDER BY al."createdAt" DESC
    `;
        try {
            const historico = await prisma.$queryRawUnsafe(sqlQuery);
            return historico.map(item => {
                let statusAnterior = null;
                let statusNovo = null;
                let observacoes = null;
                const newData = item.newData || item.new_data;
                if (newData) {
                    try {
                        const parsedData = typeof newData === 'string' ? JSON.parse(newData) : newData;
                        if (parsedData.validacao_status !== undefined) {
                            statusNovo = parsedData.validacao_status;
                        }
                        if (parsedData.validacao_obs !== undefined) {
                            observacoes = parsedData.validacao_obs;
                        }
                    }
                    catch (e) {
                        const newDataStr = typeof newData === 'string' ? newData : JSON.stringify(newData);
                        if (newDataStr.includes('validacao_status')) {
                            const match = newDataStr.match(/validacao_status["\s:]*(\d+)/);
                            if (match) {
                                statusNovo = parseInt(match[1]);
                            }
                        }
                        if (newDataStr.includes('validacao_obs')) {
                            const match = newDataStr.match(/validacao_obs["\s:]*["']([^"']+)["']/);
                            if (match) {
                                observacoes = match[1];
                            }
                        }
                    }
                }
                const oldData = item.oldData || item.old_data;
                if (oldData) {
                    try {
                        const parsedData = typeof oldData === 'string' ? JSON.parse(oldData) : oldData;
                        if (parsedData.validacao_status !== undefined) {
                            statusAnterior = parsedData.validacao_status;
                        }
                    }
                    catch (e) {
                        const oldDataStr = typeof oldData === 'string' ? oldData : JSON.stringify(oldData);
                        if (oldDataStr.includes('validacao_status')) {
                            const match = oldDataStr.match(/validacao_status["\s:]*(\d+)/);
                            if (match) {
                                statusAnterior = parseInt(match[1]);
                            }
                        }
                    }
                }
                return {
                    log_id: item.log_id,
                    qualificacao_id: item.qualificacao_id,
                    data_mudanca: item.data_mudanca,
                    status_anterior: statusAnterior,
                    status_novo: statusNovo,
                    usuario_nome: item.usuario_nome,
                    usuario_email: item.usuario_email,
                    observacoes: observacoes,
                    action: item.action
                };
            });
        }
        catch (error) {
            console.error('Erro ao buscar histórico de validação:', error);
            throw new ApiError_1.ApiError({
                message: 'Erro ao buscar histórico de validação',
                statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR,
                code: api_1.ErrorCode.DATABASE_ERROR,
                details: error.message
            });
        }
    }
}
exports.default = new QualificacaoService();
//# sourceMappingURL=qualificacaoService.js.map