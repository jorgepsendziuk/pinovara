import { Qualificacao, QualificacaoFilters, QualificacaoListResponse, CreateQualificacaoData, UpdateQualificacaoData } from '../types/qualificacao';
declare class QualificacaoService {
    list(filters?: QualificacaoFilters): Promise<QualificacaoListResponse>;
    getById(id: number): Promise<Qualificacao | null>;
    create(data: CreateQualificacaoData, userId: number): Promise<Qualificacao>;
    update(id: number, data: UpdateQualificacaoData, userId: number): Promise<Qualificacao>;
    addTecnico(idQualificacao: number, idTecnico: number, userId: number): Promise<void>;
    removeTecnico(idQualificacao: number, idTecnico: number): Promise<void>;
    listTecnicos(idQualificacao: number): Promise<Array<{
        id_tecnico: number;
        tecnico: {
            id: number;
            name: string;
            email: string;
        };
    }>>;
    delete(id: number): Promise<void>;
    listTecnicosDisponiveis(): Promise<Array<{
        id: number;
        name: string;
        email: string;
    }>>;
    updateValidacao(id: number, dadosValidacao: {
        validacao_status: number | null;
        validacao_obs: string | null;
        validacao_usuario: number | null;
        validacao_data: Date;
    }): Promise<Qualificacao>;
    getHistoricoValidacao(idQualificacao: number): Promise<any[]>;
}
declare const _default: QualificacaoService;
export default _default;
//# sourceMappingURL=qualificacaoService.d.ts.map