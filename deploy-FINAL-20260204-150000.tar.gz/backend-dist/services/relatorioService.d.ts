import { PassThrough } from 'stream';
export declare const relatorioService: {
    gerarRelatorioPDF(organizacaoId: number): Promise<PassThrough>;
};
//# sourceMappingURL=relatorioService.d.ts.map