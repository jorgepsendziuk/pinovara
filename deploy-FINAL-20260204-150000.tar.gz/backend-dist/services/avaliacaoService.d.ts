import { AvaliacaoVersao, AvaliacaoPergunta, CreateAvaliacaoVersaoData, CreateAvaliacaoPerguntaData, CapacitacaoAvaliacao, CreateAvaliacaoData, AvaliacaoEstatisticas } from '../types/avaliacao';
declare class AvaliacaoService {
    listVersoes(ativo?: boolean): Promise<AvaliacaoVersao[]>;
    getVersaoAtiva(): Promise<AvaliacaoVersao | null>;
    getVersaoById(id: number): Promise<AvaliacaoVersao | null>;
    createVersao(data: CreateAvaliacaoVersaoData, userId: number): Promise<AvaliacaoVersao>;
    updateVersao(id: number, data: Partial<CreateAvaliacaoVersaoData>, userId: number): Promise<AvaliacaoVersao>;
    listPerguntas(idVersao: number): Promise<AvaliacaoPergunta[]>;
    createPergunta(idVersao: number, data: CreateAvaliacaoPerguntaData): Promise<AvaliacaoPergunta>;
    updatePergunta(id: number, data: Partial<CreateAvaliacaoPerguntaData>): Promise<AvaliacaoPergunta>;
    deletePergunta(id: number): Promise<void>;
    createAvaliacao(idCapacitacao: number, data: CreateAvaliacaoData, idInscricao?: number): Promise<CapacitacaoAvaliacao>;
    getAvaliacaoById(id: number): Promise<CapacitacaoAvaliacao | null>;
    listAvaliacoes(idCapacitacao: number): Promise<CapacitacaoAvaliacao[]>;
    getEstatisticas(idCapacitacao: number): Promise<AvaliacaoEstatisticas[]>;
}
declare const _default: AvaliacaoService;
export default _default;
//# sourceMappingURL=avaliacaoService.d.ts.map