import { Capacitacao, CapacitacaoFilters, CapacitacaoListResponse, CreateCapacitacaoData, UpdateCapacitacaoData, CapacitacaoInscricao, CreateInscricaoData, CapacitacaoPresenca, CreatePresencaData } from '../types/capacitacao';
declare class CapacitacaoService {
    list(filters?: CapacitacaoFilters): Promise<CapacitacaoListResponse>;
    addTecnico(idCapacitacao: number, idTecnico: number, userId: number): Promise<void>;
    removeTecnico(idCapacitacao: number, idTecnico: number): Promise<void>;
    listTecnicos(idCapacitacao: number): Promise<Array<{
        id_tecnico: number;
        tecnico: {
            id: number;
            name: string;
            email: string;
        };
    }>>;
    getById(id: number): Promise<Capacitacao | null>;
    getByLinkInscricao(linkInscricao: string): Promise<Capacitacao | null>;
    getByLinkAvaliacao(linkAvaliacao: string): Promise<Capacitacao | null>;
    create(data: CreateCapacitacaoData, userId: number): Promise<Capacitacao>;
    update(id: number, data: UpdateCapacitacaoData, userId: number): Promise<Capacitacao>;
    delete(id: number): Promise<void>;
    createInscricao(idCapacitacao: number, data: CreateInscricaoData, inscritoPor?: number): Promise<CapacitacaoInscricao>;
    listInscricoes(idCapacitacao: number): Promise<CapacitacaoInscricao[]>;
    updateInscricao(idCapacitacao: number, idInscricao: number, data: Partial<CreateInscricaoData>): Promise<CapacitacaoInscricao>;
    deleteInscricao(idCapacitacao: number, idInscricao: number): Promise<void>;
    verificarInscricaoPorEmail(linkInscricao: string, email: string): Promise<CapacitacaoInscricao | null>;
    createPresenca(idCapacitacao: number, data: CreatePresencaData, createdBy?: number): Promise<CapacitacaoPresenca>;
    updatePresenca(idCapacitacao: number, idPresenca: number, data: Partial<CreatePresencaData>): Promise<CapacitacaoPresenca>;
    deletePresenca(idCapacitacao: number, idPresenca: number): Promise<void>;
    listPresencas(idCapacitacao: number): Promise<CapacitacaoPresenca[]>;
    updateValidacao(id: number, dadosValidacao: {
        validacao_status: number | null;
        validacao_obs: string | null;
        validacao_usuario: number | null;
        validacao_data: Date;
    }): Promise<Capacitacao>;
    getHistoricoValidacao(idCapacitacao: number): Promise<any[]>;
}
declare const _default: CapacitacaoService;
export default _default;
//# sourceMappingURL=capacitacaoService.d.ts.map