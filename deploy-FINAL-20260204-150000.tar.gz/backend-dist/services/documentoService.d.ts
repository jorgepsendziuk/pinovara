interface CreateDocumentoDTO {
    id_organizacao: number;
    arquivo: string;
    usuario_envio: string;
    obs?: string;
    uri: string;
    ordinal_number: number;
}
interface UpdateDocumentoDTO {
    obs?: string;
    last_update_uri_user?: string;
    last_update_date?: Date;
}
export declare const documentoService: {
    create(data: CreateDocumentoDTO): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        arquivo: string | null;
    }>;
    findByOrganizacao(organizacaoId: number): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        arquivo: string | null;
    }[]>;
    findById(id: number): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        arquivo: string | null;
    } | null>;
    update(id: number, data: UpdateDocumentoDTO): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        arquivo: string | null;
    }>;
    delete(id: number): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        arquivo: string | null;
    }>;
    count(organizacaoId: number): Promise<number>;
};
export {};
//# sourceMappingURL=documentoService.d.ts.map