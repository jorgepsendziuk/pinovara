interface CreateFotoDTO {
    foto: string;
    obs?: string;
    id_organizacao: number;
    creator_uri_user: string;
}
interface UpdateFotoDTO {
    obs?: string;
}
export declare const fotoService: {
    create(data: CreateFotoDTO): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        foto: string | null;
        grupo: number | null;
    }>;
    listByOrganizacao(organizacaoId: number): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        foto: string | null;
        grupo: number | null;
    }[]>;
    findById(id: number): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        foto: string | null;
        grupo: number | null;
    } | null>;
    update(id: number, data: UpdateFotoDTO): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        foto: string | null;
        grupo: number | null;
    }>;
    delete(id: number): Promise<{
        id: number;
        id_organizacao: number | null;
        uri: string;
        obs: string | null;
        creator_uri_user: string;
        creation_date: Date;
        last_update_uri_user: string | null;
        last_update_date: Date;
        parent_auri: string | null;
        ordinal_number: number;
        top_level_auri: string | null;
        foto: string | null;
        grupo: number | null;
    }>;
};
export {};
//# sourceMappingURL=fotoService.d.ts.map