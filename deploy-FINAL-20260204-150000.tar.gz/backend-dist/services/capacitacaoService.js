"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const crypto_1 = require("crypto");
const api_1 = require("../types/api");
const ApiError_1 = require("../utils/ApiError");
const prisma = new client_1.PrismaClient();
class CapacitacaoService {
    async list(filters = {}) {
        const { page = 1, limit = 10, id_qualificacao, status, id_organizacao, created_by, data_inicio, data_fim, titulo } = filters;
        const filterByUser = filters.filterByUser;
        const userId = filters.userId;
        const whereConditions = {};
        if (id_qualificacao) {
            whereConditions.id_qualificacao = id_qualificacao;
        }
        if (status) {
            whereConditions.status = status;
        }
        let userFilter = null;
        if (filterByUser && userId) {
            let idsCompartilhadas = [];
            try {
                const capacitacoesCompartilhadas = await prisma.capacitacao_tecnico.findMany({
                    where: { id_tecnico: userId },
                    select: { id_capacitacao: true }
                });
                idsCompartilhadas = capacitacoesCompartilhadas.map(ct => ct.id_capacitacao);
            }
            catch (error) {
                console.warn('Tabela capacitacao_tecnico ainda não existe ou erro ao buscar compartilhamentos:', error.message);
            }
            userFilter = {
                OR: [
                    { created_by: userId },
                    ...(idsCompartilhadas.length > 0 ? [{ id: { in: idsCompartilhadas } }] : [])
                ]
            };
        }
        else if (created_by) {
            whereConditions.created_by = created_by;
        }
        let tituloFilter = null;
        if (titulo) {
            tituloFilter = {
                OR: [
                    { titulo: { contains: titulo, mode: 'insensitive' } },
                    { qualificacao: { titulo: { contains: titulo, mode: 'insensitive' } } }
                ]
            };
        }
        if (tituloFilter && userFilter) {
            whereConditions.AND = [tituloFilter, userFilter];
        }
        else if (tituloFilter) {
            Object.assign(whereConditions, tituloFilter);
        }
        else if (userFilter) {
            Object.assign(whereConditions, userFilter);
        }
        if (data_inicio) {
            whereConditions.data_inicio = {
                gte: data_inicio
            };
        }
        if (data_fim) {
            whereConditions.data_fim = {
                lte: data_fim
            };
        }
        if (id_organizacao) {
            whereConditions.capacitacao_organizacao = {
                some: {
                    id_organizacao: id_organizacao
                }
            };
        }
        const skip = (page - 1) * limit;
        const [capacitacoes, total] = await Promise.all([
            prisma.capacitacao.findMany({
                where: whereConditions,
                skip,
                take: limit,
                orderBy: { id: 'desc' },
                include: {
                    qualificacao: {
                        select: {
                            id: true,
                            titulo: true
                        }
                    },
                    capacitacao_organizacao: {
                        select: {
                            id_organizacao: true
                        }
                    },
                    capacitacao_tecnico: {
                        select: {
                            id_tecnico: true,
                            tecnico: {
                                select: {
                                    id: true,
                                    name: true,
                                    email: true
                                }
                            }
                        }
                    },
                    _count: {
                        select: {
                            capacitacao_inscricao: true
                        }
                    }
                }
            }),
            prisma.capacitacao.count({ where: whereConditions })
        ]);
        const criadoresIds = capacitacoes
            .filter(c => c.created_by)
            .map(c => c.created_by)
            .filter((id, index, self) => self.indexOf(id) === index);
        const criadores = criadoresIds.length > 0 ? await prisma.users.findMany({
            where: {
                id: { in: criadoresIds }
            },
            select: {
                id: true,
                name: true,
                email: true
            }
        }) : [];
        const todasOrganizacoesIds = capacitacoes
            .flatMap(c => c.capacitacao_organizacao.map(co => co.id_organizacao))
            .filter((id, index, self) => self.indexOf(id) === index);
        const organizacoesCompletas = todasOrganizacoesIds.length > 0 ? await prisma.organizacao.findMany({
            where: {
                id: { in: todasOrganizacoesIds }
            },
            select: {
                id: true,
                nome: true,
                id_tecnico: true
            }
        }) : [];
        const tecnicosIds = organizacoesCompletas
            .filter(org => org.id_tecnico)
            .map(org => org.id_tecnico)
            .filter((id, index, self) => self.indexOf(id) === index);
        const tecnicos = tecnicosIds.length > 0 ? await prisma.users.findMany({
            where: {
                id: { in: tecnicosIds }
            },
            select: {
                id: true,
                name: true,
                email: true
            }
        }) : [];
        const organizacoesComTecnicosMap = new Map(organizacoesCompletas.map(org => [
            org.id,
            {
                id: org.id,
                nome: org.nome,
                tecnico: org.id_tecnico ? tecnicos.find(t => t.id === org.id_tecnico) : null
            }
        ]));
        const formattedCapacitacoes = capacitacoes.map(c => {
            const criador = c.created_by ? criadores.find(cr => cr.id === c.created_by) : null;
            const organizacoesIds = c.capacitacao_organizacao.map(co => co.id_organizacao);
            const organizacoesCompletasParaCapacitacao = organizacoesIds
                .map(id => organizacoesComTecnicosMap.get(id))
                .filter((org) => org !== undefined);
            return {
                ...c,
                organizacoes: organizacoesIds,
                organizacoes_completas: organizacoesCompletasParaCapacitacao,
                equipe_tecnica: (c.capacitacao_tecnico || []).map(ct => ({
                    id_tecnico: ct.id_tecnico,
                    tecnico: ct.tecnico
                })),
                tecnico_criador: criador ? {
                    id: criador.id,
                    name: criador.name,
                    email: criador.email
                } : null,
                total_inscritos: c._count?.capacitacao_inscricao || 0
            };
        });
        return {
            capacitacoes: formattedCapacitacoes,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit)
        };
    }
    async addTecnico(idCapacitacao, idTecnico, userId) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { id: idCapacitacao }
        });
        if (!capacitacao) {
            throw new Error('Capacitação não encontrada');
        }
        const existing = await prisma.capacitacao_tecnico.findUnique({
            where: {
                id_capacitacao_id_tecnico: {
                    id_capacitacao: idCapacitacao,
                    id_tecnico: idTecnico
                }
            }
        });
        if (existing) {
            throw new Error('Técnico já está na equipe desta capacitação');
        }
        await prisma.capacitacao_tecnico.create({
            data: {
                id_capacitacao: idCapacitacao,
                id_tecnico: idTecnico,
                created_by: userId
            }
        });
    }
    async removeTecnico(idCapacitacao, idTecnico) {
        await prisma.capacitacao_tecnico.delete({
            where: {
                id_capacitacao_id_tecnico: {
                    id_capacitacao: idCapacitacao,
                    id_tecnico: idTecnico
                }
            }
        });
    }
    async listTecnicos(idCapacitacao) {
        const tecnicos = await prisma.capacitacao_tecnico.findMany({
            where: { id_capacitacao: idCapacitacao },
            include: {
                tecnico: {
                    select: {
                        id: true,
                        name: true,
                        email: true
                    }
                }
            }
        });
        return tecnicos.map(t => ({
            id_tecnico: t.id_tecnico,
            tecnico: t.tecnico
        }));
    }
    async getById(id) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { id },
            include: {
                qualificacao: {
                    select: {
                        id: true,
                        titulo: true
                    }
                },
                capacitacao_organizacao: {
                    select: {
                        id_organizacao: true
                    }
                },
                capacitacao_tecnico: {
                    select: {
                        id_tecnico: true,
                        tecnico: {
                            select: {
                                id: true,
                                name: true,
                                email: true
                            }
                        }
                    }
                },
                validacao_usuario_user: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                }
            }
        });
        if (!capacitacao) {
            return null;
        }
        const organizacoesIds = capacitacao.capacitacao_organizacao.map(co => co.id_organizacao);
        const organizacoesCompletas = organizacoesIds.length > 0 ? await prisma.organizacao.findMany({
            where: {
                id: { in: organizacoesIds }
            },
            select: {
                id: true,
                nome: true,
                id_tecnico: true
            }
        }) : [];
        const tecnicosIds = organizacoesCompletas
            .filter(org => org.id_tecnico)
            .map(org => org.id_tecnico)
            .filter((id, index, self) => self.indexOf(id) === index);
        const tecnicos = tecnicosIds.length > 0 ? await prisma.users.findMany({
            where: {
                id: { in: tecnicosIds }
            },
            select: {
                id: true,
                name: true,
                email: true
            }
        }) : [];
        const organizacoesComTecnicos = organizacoesCompletas.map(org => ({
            id: org.id,
            nome: org.nome,
            tecnico: org.id_tecnico ? tecnicos.find(t => t.id === org.id_tecnico) : null
        }));
        let tecnicoCriador = null;
        if (capacitacao.created_by) {
            const criador = await prisma.users.findUnique({
                where: { id: capacitacao.created_by },
                select: {
                    id: true,
                    name: true,
                    email: true
                }
            });
            tecnicoCriador = criador;
        }
        return {
            ...capacitacao,
            organizacoes: organizacoesIds,
            organizacoes_completas: organizacoesComTecnicos,
            equipe_tecnica: (capacitacao.capacitacao_tecnico || []).map(ct => ({
                id_tecnico: ct.id_tecnico,
                tecnico: ct.tecnico
            })),
            tecnico_criador: tecnicoCriador,
            validacao_usuario_nome: capacitacao.validacao_usuario_user?.name || null
        };
    }
    async getByLinkInscricao(linkInscricao) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { link_inscricao: linkInscricao },
            include: {
                qualificacao: {
                    select: {
                        id: true,
                        titulo: true,
                        objetivo_geral: true,
                        conteudo_programatico: true,
                        metodologia: true,
                        recursos_didaticos: true,
                        estrategia_avaliacao: true,
                        referencias: true
                    }
                },
                capacitacao_organizacao: {
                    select: {
                        id_organizacao: true
                    }
                }
            }
        });
        if (!capacitacao) {
            return null;
        }
        const organizacoesIds = capacitacao.capacitacao_organizacao.map(co => co.id_organizacao);
        const organizacoesCompletas = organizacoesIds.length > 0 ? await prisma.organizacao.findMany({
            where: {
                id: { in: organizacoesIds }
            },
            select: {
                id: true,
                nome: true,
                id_tecnico: true
            }
        }) : [];
        const tecnicosIds = organizacoesCompletas
            .filter(org => org.id_tecnico)
            .map(org => org.id_tecnico)
            .filter((id, index, self) => self.indexOf(id) === index);
        const tecnicos = tecnicosIds.length > 0 ? await prisma.users.findMany({
            where: {
                id: { in: tecnicosIds }
            },
            select: {
                id: true,
                name: true,
                email: true
            }
        }) : [];
        const organizacoesComTecnicos = organizacoesCompletas.map(org => ({
            id: org.id,
            nome: org.nome,
            tecnico: org.id_tecnico ? tecnicos.find(t => t.id === org.id_tecnico) : null
        }));
        let tecnicoCriador = null;
        if (capacitacao.created_by) {
            const criador = await prisma.users.findUnique({
                where: { id: capacitacao.created_by },
                select: {
                    id: true,
                    name: true,
                    email: true
                }
            });
            if (criador) {
                tecnicoCriador = {
                    id: criador.id,
                    name: criador.name,
                    email: criador.email
                };
            }
        }
        return {
            ...capacitacao,
            organizacoes: organizacoesIds,
            organizacoes_completas: organizacoesComTecnicos,
            tecnico_criador: tecnicoCriador
        };
    }
    async getByLinkAvaliacao(linkAvaliacao) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { link_avaliacao: linkAvaliacao },
            include: {
                qualificacao: {
                    select: {
                        id: true,
                        titulo: true
                    }
                }
            }
        });
        if (!capacitacao) {
            return null;
        }
        return capacitacao;
    }
    async create(data, userId) {
        const { organizacoes, ...capacitacaoData } = data;
        if (!data.id_qualificacao) {
            throw new ApiError_1.ApiError({
                message: 'Qualificação é obrigatória',
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.MISSING_REQUIRED_FIELD
            });
        }
        const qualificacao = await prisma.qualificacao.findUnique({
            where: { id: data.id_qualificacao }
        });
        if (!qualificacao) {
            throw new ApiError_1.ApiError({
                message: 'Qualificação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const linkInscricao = (0, crypto_1.randomUUID)();
        const linkAvaliacao = (0, crypto_1.randomUUID)();
        const dataToCreate = {
            id_qualificacao: capacitacaoData.id_qualificacao,
            titulo: capacitacaoData.titulo || null,
            local: capacitacaoData.local || null,
            turno: capacitacaoData.turno || null,
            status: capacitacaoData.status || 'planejada',
            link_inscricao: linkInscricao,
            link_avaliacao: linkAvaliacao,
            created_by: userId
        };
        if (capacitacaoData.data_inicio) {
            dataToCreate.data_inicio = capacitacaoData.data_inicio instanceof Date
                ? capacitacaoData.data_inicio
                : new Date(capacitacaoData.data_inicio);
        }
        if (capacitacaoData.data_fim) {
            dataToCreate.data_fim = capacitacaoData.data_fim instanceof Date
                ? capacitacaoData.data_fim
                : new Date(capacitacaoData.data_fim);
        }
        const capacitacao = await prisma.capacitacao.create({
            data: dataToCreate
        });
        if (organizacoes && organizacoes.length > 0) {
            await prisma.capacitacao_organizacao.createMany({
                data: organizacoes.map(id_organizacao => ({
                    id_capacitacao: capacitacao.id,
                    id_organizacao
                })),
                skipDuplicates: true
            });
        }
        return this.getById(capacitacao.id);
    }
    async update(id, data, userId) {
        const existing = await prisma.capacitacao.findUnique({
            where: { id }
        });
        if (!existing) {
            throw new ApiError_1.ApiError({
                message: 'Capacitação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const { organizacoes, ...capacitacaoData } = data;
        const dataToUpdate = {
            updated_at: new Date()
        };
        if (capacitacaoData.id_qualificacao !== undefined) {
            dataToUpdate.id_qualificacao = capacitacaoData.id_qualificacao;
        }
        if (capacitacaoData.titulo !== undefined) {
            dataToUpdate.titulo = capacitacaoData.titulo || null;
        }
        if (capacitacaoData.local !== undefined) {
            dataToUpdate.local = capacitacaoData.local || null;
        }
        if (capacitacaoData.turno !== undefined) {
            dataToUpdate.turno = capacitacaoData.turno || null;
        }
        if (capacitacaoData.status !== undefined) {
            dataToUpdate.status = capacitacaoData.status;
        }
        if (capacitacaoData.data_inicio !== undefined) {
            dataToUpdate.data_inicio = capacitacaoData.data_inicio instanceof Date
                ? capacitacaoData.data_inicio
                : capacitacaoData.data_inicio ? new Date(capacitacaoData.data_inicio) : null;
        }
        if (capacitacaoData.data_fim !== undefined) {
            dataToUpdate.data_fim = capacitacaoData.data_fim instanceof Date
                ? capacitacaoData.data_fim
                : capacitacaoData.data_fim ? new Date(capacitacaoData.data_fim) : null;
        }
        const updated = await prisma.capacitacao.update({
            where: { id },
            data: dataToUpdate
        });
        if (organizacoes !== undefined) {
            await prisma.capacitacao_organizacao.deleteMany({
                where: { id_capacitacao: id }
            });
            if (organizacoes.length > 0) {
                await prisma.capacitacao_organizacao.createMany({
                    data: organizacoes.map(id_organizacao => ({
                        id_capacitacao: id,
                        id_organizacao
                    })),
                    skipDuplicates: true
                });
            }
        }
        return this.getById(id);
    }
    async delete(id) {
        const existing = await prisma.capacitacao.findUnique({
            where: { id }
        });
        if (!existing) {
            throw new ApiError_1.ApiError({
                message: 'Capacitação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        await prisma.capacitacao.delete({
            where: { id }
        });
    }
    async createInscricao(idCapacitacao, data, inscritoPor) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { id: idCapacitacao }
        });
        if (!capacitacao) {
            throw new ApiError_1.ApiError({
                message: 'Capacitação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        if (!data.nome || data.nome.trim().length === 0) {
            throw new ApiError_1.ApiError({
                message: 'Nome é obrigatório',
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.MISSING_REQUIRED_FIELD
            });
        }
        const emailNormalizado = data.email?.trim().toLowerCase() || null;
        if (emailNormalizado) {
            const inscricoesExistentes = await prisma.capacitacao_inscricao.findMany({
                where: {
                    id_capacitacao: idCapacitacao,
                    email: { not: null }
                },
                select: {
                    email: true
                }
            });
            const emailJaExiste = inscricoesExistentes.some(insc => insc.email?.trim().toLowerCase() === emailNormalizado);
            if (emailJaExiste) {
                throw new ApiError_1.ApiError({
                    message: 'Já existe uma inscrição com este email para esta capacitação. Cada email só pode se inscrever uma vez.',
                    statusCode: api_1.HttpStatus.BAD_REQUEST,
                    code: api_1.ErrorCode.RESOURCE_ALREADY_EXISTS
                });
            }
        }
        const inscricao = await prisma.capacitacao_inscricao.create({
            data: {
                id_capacitacao: idCapacitacao,
                nome: data.nome.trim(),
                email: emailNormalizado,
                telefone: data.telefone?.trim() || null,
                instituicao: data.instituicao?.trim() || null,
                cpf: data.cpf?.trim() || null,
                rg: data.rg?.trim() || null,
                inscrito_por: inscritoPor || null
            }
        });
        return inscricao;
    }
    async listInscricoes(idCapacitacao) {
        const inscricoes = await prisma.capacitacao_inscricao.findMany({
            where: { id_capacitacao: idCapacitacao },
            orderBy: { created_at: 'asc' }
        });
        return inscricoes;
    }
    async updateInscricao(idCapacitacao, idInscricao, data) {
        const inscricao = await prisma.capacitacao_inscricao.findFirst({
            where: {
                id: idInscricao,
                id_capacitacao: idCapacitacao
            }
        });
        if (!inscricao) {
            throw new ApiError_1.ApiError({
                message: 'Inscrição não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const emailNormalizado = data.email?.trim().toLowerCase() || null;
        if (emailNormalizado && emailNormalizado !== inscricao.email?.trim().toLowerCase()) {
            const inscricoesExistentes = await prisma.capacitacao_inscricao.findMany({
                where: {
                    id_capacitacao: idCapacitacao,
                    email: { not: null },
                    id: { not: idInscricao }
                },
                select: {
                    email: true
                }
            });
            const emailJaExiste = inscricoesExistentes.some(insc => insc.email?.trim().toLowerCase() === emailNormalizado);
            if (emailJaExiste) {
                throw new ApiError_1.ApiError({
                    message: 'Já existe uma inscrição com este email para esta capacitação',
                    statusCode: api_1.HttpStatus.BAD_REQUEST,
                    code: api_1.ErrorCode.RESOURCE_ALREADY_EXISTS
                });
            }
        }
        const updated = await prisma.capacitacao_inscricao.update({
            where: { id: idInscricao },
            data: {
                nome: data.nome?.trim() || inscricao.nome,
                email: emailNormalizado || inscricao.email,
                telefone: data.telefone?.trim() || inscricao.telefone,
                instituicao: data.instituicao?.trim() || inscricao.instituicao,
                cpf: data.cpf?.trim() || inscricao.cpf,
                rg: data.rg?.trim() || inscricao.rg
            }
        });
        return updated;
    }
    async deleteInscricao(idCapacitacao, idInscricao) {
        const inscricao = await prisma.capacitacao_inscricao.findFirst({
            where: {
                id: idInscricao,
                id_capacitacao: idCapacitacao
            }
        });
        if (!inscricao) {
            throw new ApiError_1.ApiError({
                message: 'Inscrição não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        await prisma.capacitacao_inscricao.delete({
            where: { id: idInscricao }
        });
    }
    async verificarInscricaoPorEmail(linkInscricao, email) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { link_inscricao: linkInscricao }
        });
        if (!capacitacao) {
            return null;
        }
        const emailNormalizado = email.trim().toLowerCase();
        const inscricoes = await prisma.capacitacao_inscricao.findMany({
            where: {
                id_capacitacao: capacitacao.id,
                email: { not: null }
            }
        });
        const inscricao = inscricoes.find(insc => insc.email?.trim().toLowerCase() === emailNormalizado);
        return inscricao;
    }
    async createPresenca(idCapacitacao, data, createdBy) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { id: idCapacitacao }
        });
        if (!capacitacao) {
            throw new ApiError_1.ApiError({
                message: 'Capacitação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        if (data.id_inscricao) {
            const inscricao = await prisma.capacitacao_inscricao.findUnique({
                where: { id: data.id_inscricao }
            });
            if (!inscricao || inscricao.id_capacitacao !== idCapacitacao) {
                throw new ApiError_1.ApiError({
                    message: 'Inscrição não encontrada ou não pertence a esta capacitação',
                    statusCode: api_1.HttpStatus.NOT_FOUND,
                    code: api_1.ErrorCode.RESOURCE_NOT_FOUND
                });
            }
        }
        else if (!data.nome || data.nome.trim().length === 0) {
            throw new ApiError_1.ApiError({
                message: 'Nome é obrigatório para presenças avulsas',
                statusCode: api_1.HttpStatus.BAD_REQUEST,
                code: api_1.ErrorCode.MISSING_REQUIRED_FIELD
            });
        }
        let dataPresenca;
        if (data.data) {
            if (typeof data.data === 'string') {
                const dateStr = data.data.trim();
                if (dateStr) {
                    dataPresenca = new Date(dateStr + 'T00:00:00');
                }
                else {
                    dataPresenca = new Date();
                }
            }
            else if (data.data instanceof Date) {
                dataPresenca = data.data;
            }
            else {
                dataPresenca = new Date();
            }
        }
        else {
            dataPresenca = new Date();
        }
        const presenca = await prisma.capacitacao_presenca.create({
            data: {
                id_capacitacao: idCapacitacao,
                id_inscricao: data.id_inscricao || null,
                nome: data.nome?.trim() || null,
                presente: data.presente !== undefined ? data.presente : true,
                data: dataPresenca,
                created_by: createdBy || null
            }
        });
        return presenca;
    }
    async updatePresenca(idCapacitacao, idPresenca, data) {
        const presenca = await prisma.capacitacao_presenca.findFirst({
            where: {
                id: idPresenca,
                id_capacitacao: idCapacitacao
            }
        });
        if (!presenca) {
            throw new ApiError_1.ApiError({
                message: 'Presença não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        let dataPresenca;
        if (data.data) {
            if (typeof data.data === 'string') {
                dataPresenca = new Date(data.data);
            }
            else if (data.data instanceof Date) {
                dataPresenca = data.data;
            }
        }
        const updateData = {};
        if (data.id_inscricao !== undefined) {
            updateData.id_inscricao = data.id_inscricao || null;
        }
        if (data.nome !== undefined) {
            updateData.nome = data.nome?.trim() || null;
        }
        if (data.presente !== undefined) {
            updateData.presente = data.presente;
        }
        if (dataPresenca) {
            updateData.data = dataPresenca;
        }
        const presencaAtualizada = await prisma.capacitacao_presenca.update({
            where: { id: idPresenca },
            data: updateData
        });
        return presencaAtualizada;
    }
    async deletePresenca(idCapacitacao, idPresenca) {
        const presenca = await prisma.capacitacao_presenca.findFirst({
            where: {
                id: idPresenca,
                id_capacitacao: idCapacitacao
            }
        });
        if (!presenca) {
            throw new ApiError_1.ApiError({
                message: 'Presença não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        await prisma.capacitacao_presenca.delete({
            where: { id: idPresenca }
        });
    }
    async listPresencas(idCapacitacao) {
        const presencas = await prisma.capacitacao_presenca.findMany({
            where: { id_capacitacao: idCapacitacao },
            include: {
                capacitacao_inscricao: {
                    select: {
                        id: true,
                        nome: true,
                        email: true
                    }
                }
            },
            orderBy: { data: 'desc' }
        });
        return presencas;
    }
    async updateValidacao(id, dadosValidacao) {
        const existingCapacitacao = await prisma.capacitacao.findUnique({
            where: { id }
        });
        if (!existingCapacitacao) {
            throw new ApiError_1.ApiError({
                message: 'Capacitação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const capacitacao = await prisma.capacitacao.update({
            where: { id },
            data: {
                validacao_status: dadosValidacao.validacao_status,
                validacao_obs: dadosValidacao.validacao_obs,
                validacao_usuario: dadosValidacao.validacao_usuario,
                validacao_data: dadosValidacao.validacao_data
            }
        });
        return capacitacao;
    }
    async getHistoricoValidacao(idCapacitacao) {
        const capacitacao = await prisma.capacitacao.findUnique({
            where: { id: idCapacitacao },
            select: { id: true, titulo: true }
        });
        if (!capacitacao) {
            throw new ApiError_1.ApiError({
                message: 'Capacitação não encontrada',
                statusCode: api_1.HttpStatus.NOT_FOUND,
                code: api_1.ErrorCode.RESOURCE_NOT_FOUND
            });
        }
        const sqlQuery = `
      SELECT 
        al.id AS log_id,
        al."entityId"::integer AS capacitacao_id,
        al.action,
        al."createdAt" AS data_mudanca,
        al."userId",
        u.name AS usuario_nome,
        u.email AS usuario_email,
        al."oldData",
        al."newData"
      FROM pinovara.audit_logs al
      LEFT JOIN pinovara.users u ON al."userId" = u.id
      WHERE al.entity = 'capacitacao' 
        AND al."entityId"::integer = ${idCapacitacao}
        AND (
          al.action LIKE '%validacao%' 
          OR al.action LIKE '%validation%' 
          OR al."newData"::text LIKE '%validacao_status%'
          OR al."oldData"::text LIKE '%validacao_status%'
        )
      ORDER BY al."createdAt" DESC
    `;
        try {
            const historico = await prisma.$queryRawUnsafe(sqlQuery);
            return historico.map(item => {
                let statusAnterior = null;
                let statusNovo = null;
                let observacoes = null;
                const newData = item.newData || item.new_data;
                if (newData) {
                    try {
                        const parsedData = typeof newData === 'string' ? JSON.parse(newData) : newData;
                        if (parsedData.validacao_status !== undefined) {
                            statusNovo = parsedData.validacao_status;
                        }
                        if (parsedData.validacao_obs !== undefined) {
                            observacoes = parsedData.validacao_obs;
                        }
                    }
                    catch (e) {
                        const newDataStr = typeof newData === 'string' ? newData : JSON.stringify(newData);
                        if (newDataStr.includes('validacao_status')) {
                            const match = newDataStr.match(/validacao_status["\s:]*(\d+)/);
                            if (match) {
                                statusNovo = parseInt(match[1]);
                            }
                        }
                        if (newDataStr.includes('validacao_obs')) {
                            const match = newDataStr.match(/validacao_obs["\s:]*["']([^"']+)["']/);
                            if (match) {
                                observacoes = match[1];
                            }
                        }
                    }
                }
                const oldData = item.oldData || item.old_data;
                if (oldData) {
                    try {
                        const parsedData = typeof oldData === 'string' ? JSON.parse(oldData) : oldData;
                        if (parsedData.validacao_status !== undefined) {
                            statusAnterior = parsedData.validacao_status;
                        }
                    }
                    catch (e) {
                        const oldDataStr = typeof oldData === 'string' ? oldData : JSON.stringify(oldData);
                        if (oldDataStr.includes('validacao_status')) {
                            const match = oldDataStr.match(/validacao_status["\s:]*(\d+)/);
                            if (match) {
                                statusAnterior = parseInt(match[1]);
                            }
                        }
                    }
                }
                return {
                    log_id: item.log_id,
                    capacitacao_id: item.capacitacao_id,
                    data_mudanca: item.data_mudanca,
                    status_anterior: statusAnterior,
                    status_novo: statusNovo,
                    usuario_nome: item.usuario_nome,
                    usuario_email: item.usuario_email,
                    observacoes: observacoes,
                    action: item.action
                };
            });
        }
        catch (error) {
            console.error('Erro ao buscar histórico de validação:', error);
            throw new ApiError_1.ApiError({
                message: 'Erro ao buscar histórico de validação',
                statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR,
                code: api_1.ErrorCode.DATABASE_ERROR,
                details: error.message
            });
        }
    }
}
exports.default = new CapacitacaoService();
//# sourceMappingURL=capacitacaoService.js.map