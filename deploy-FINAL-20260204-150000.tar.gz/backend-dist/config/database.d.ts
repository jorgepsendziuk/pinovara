import { PrismaClient } from '@prisma/client';
declare let prisma: PrismaClient;
export default prisma;
//# sourceMappingURL=database.d.ts.map