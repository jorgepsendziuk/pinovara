export declare function mapFamiliaFromDB(familia: any): any;
export declare function mapFamiliaToDB(familia: any): any;
//# sourceMappingURL=familiaFieldMapper.d.ts.map