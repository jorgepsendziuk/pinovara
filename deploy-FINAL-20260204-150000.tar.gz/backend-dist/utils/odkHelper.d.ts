export declare function extractEmailFromCreatorUri(creatorUri: string | null | undefined): string | null;
export declare function isValidCreatorUri(creatorUri: string | null | undefined): boolean;
//# sourceMappingURL=odkHelper.d.ts.map