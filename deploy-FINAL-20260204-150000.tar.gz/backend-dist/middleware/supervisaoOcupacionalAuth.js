"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkSupervisaoOcupacionalPermission = void 0;
const api_1 = require("../types/api");
const checkSupervisaoOcupacionalPermission = async (req, res, next) => {
    try {
        const user = req.user;
        if (!user) {
            res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                success: false,
                error: {
                    message: 'Usuário não autenticado',
                    code: api_1.ErrorCode.AUTHENTICATION_REQUIRED,
                    statusCode: api_1.HttpStatus.UNAUTHORIZED
                },
                timestamp: new Date().toISOString()
            });
            return;
        }
        const isSystemAdmin = user.roles?.some((role) => role.module?.name === 'sistema' && role.name === 'admin');
        const isModuleAdmin = user.roles?.some((role) => role.module?.name === 'supervisao_ocupacional' && role.name === 'admin');
        const isCoordinator = user.roles?.some((role) => role.module?.name === 'supervisao_ocupacional' && role.name === 'coordenador');
        const isSupervisor = user.roles?.some((role) => role.module?.name === 'supervisao_ocupacional' && role.name === 'supervisor');
        const isTechnician = user.roles?.some((role) => role.module?.name === 'supervisao_ocupacional' && role.name === 'tecnico');
        const isEstagiario = user.roles?.some((role) => role.module?.name === 'supervisao_ocupacional' && role.name === 'estagiario');
        const hasPermission = isSystemAdmin || isModuleAdmin || isCoordinator || isSupervisor || isTechnician || isEstagiario;
        if (!hasPermission) {
            res.status(api_1.HttpStatus.FORBIDDEN).json({
                success: false,
                error: {
                    message: 'Acesso negado ao módulo de Supervisão Ocupacional',
                    code: api_1.ErrorCode.INSUFFICIENT_PERMISSIONS,
                    statusCode: api_1.HttpStatus.FORBIDDEN
                },
                timestamp: new Date().toISOString()
            });
            return;
        }
        req.userPermissions = {
            userId: user.id,
            roles: user.roles,
            isSystemAdmin,
            isModuleAdmin,
            isCoordinator,
            isSupervisor,
            isTechnician,
            isEstagiario,
            canViewAll: isSystemAdmin || isModuleAdmin || isCoordinator || isSupervisor || isTechnician,
            canEdit: isSystemAdmin || isModuleAdmin || isTechnician,
            canValidate: isSystemAdmin || isModuleAdmin || isCoordinator,
            canViewOwnOnly: isTechnician || isEstagiario
        };
        next();
    }
    catch (error) {
        console.error('Erro no middleware de permissões:', error);
        res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
            success: false,
            error: {
                message: 'Erro ao verificar permissões',
                code: api_1.ErrorCode.INTERNAL_ERROR,
                statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
            },
            timestamp: new Date().toISOString()
        });
    }
};
exports.checkSupervisaoOcupacionalPermission = checkSupervisaoOcupacionalPermission;
//# sourceMappingURL=supervisaoOcupacionalAuth.js.map