import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
export declare const checkSupervisaoOcupacionalPermission: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=supervisaoOcupacionalAuth.d.ts.map