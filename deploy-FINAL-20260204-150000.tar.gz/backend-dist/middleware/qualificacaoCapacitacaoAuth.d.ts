import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
export declare const checkQualificacaoCapacitacaoPermission: (req: AuthRequest, res: Response, next: NextFunction) => void;
declare const _default: {
    checkQualificacaoCapacitacaoPermission: (req: AuthRequest, res: Response, next: NextFunction) => void;
};
export default _default;
//# sourceMappingURL=qualificacaoCapacitacaoAuth.d.ts.map