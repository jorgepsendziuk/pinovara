"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkQualificacaoCapacitacaoPermission = void 0;
const api_1 = require("../types/api");
const checkQualificacaoCapacitacaoPermission = (req, res, next) => {
    if (!req.user) {
        res.status(api_1.HttpStatus.UNAUTHORIZED).json({
            success: false,
            error: {
                message: 'Usuário não autenticado',
                code: api_1.ErrorCode.AUTHENTICATION_REQUIRED,
                statusCode: api_1.HttpStatus.UNAUTHORIZED
            },
            timestamp: new Date().toISOString()
        });
        return;
    }
    const isAdmin = req.user.roles?.some(role => role.name === 'admin' && role.module.name === 'sistema');
    const isCoordinator = req.user.roles?.some(role => role.name === 'coordenador' && role.module.name === 'organizacoes');
    const isSupervisor = req.user.roles?.some(role => role.name === 'supervisao' && role.module.name === 'organizacoes');
    const isTechnician = req.user.roles?.some(role => role.name === 'tecnico' && role.module.name === 'organizacoes');
    req.userPermissions = {
        isAdmin,
        isCoordinator,
        isSupervisor,
        isTechnician,
        canAccessAll: isAdmin || isCoordinator || isSupervisor,
        canEdit: isAdmin,
        canValidate: isAdmin || isCoordinator,
        userId: req.user.id
    };
    next();
};
exports.checkQualificacaoCapacitacaoPermission = checkQualificacaoCapacitacaoPermission;
exports.default = {
    checkQualificacaoCapacitacaoPermission: exports.checkQualificacaoCapacitacaoPermission
};
//# sourceMappingURL=qualificacaoCapacitacaoAuth.js.map