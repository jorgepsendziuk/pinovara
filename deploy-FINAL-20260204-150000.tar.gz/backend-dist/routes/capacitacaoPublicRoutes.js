"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const capacitacaoPublicController_1 = require("../controllers/capacitacaoPublicController");
const router = (0, express_1.Router)();
router.get('/:linkInscricao', capacitacaoPublicController_1.capacitacaoPublicController.getByLinkInscricao.bind(capacitacaoPublicController_1.capacitacaoPublicController));
router.post('/:linkInscricao/inscricao', capacitacaoPublicController_1.capacitacaoPublicController.createInscricaoPublica.bind(capacitacaoPublicController_1.capacitacaoPublicController));
router.post('/:linkInscricao/verificar-inscricao', capacitacaoPublicController_1.capacitacaoPublicController.verificarInscricao.bind(capacitacaoPublicController_1.capacitacaoPublicController));
router.get('/:linkAvaliacao/avaliacao', capacitacaoPublicController_1.capacitacaoPublicController.getByLinkAvaliacao.bind(capacitacaoPublicController_1.capacitacaoPublicController));
router.post('/:linkAvaliacao/avaliacao', capacitacaoPublicController_1.capacitacaoPublicController.createAvaliacaoPublica.bind(capacitacaoPublicController_1.capacitacaoPublicController));
router.get('/:linkInscricao/materiais', capacitacaoPublicController_1.capacitacaoPublicController.listMateriaisPublicos.bind(capacitacaoPublicController_1.capacitacaoPublicController));
router.get('/:linkInscricao/materiais/:materialId/download', capacitacaoPublicController_1.capacitacaoPublicController.downloadMaterialPublico.bind(capacitacaoPublicController_1.capacitacaoPublicController));
exports.default = router;
//# sourceMappingURL=capacitacaoPublicRoutes.js.map