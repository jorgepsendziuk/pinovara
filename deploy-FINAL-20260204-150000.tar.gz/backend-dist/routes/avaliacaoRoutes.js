"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const avaliacaoController_1 = require("../controllers/avaliacaoController");
const auth_1 = require("../middleware/auth");
const adminAuth_1 = require("../middleware/adminAuth");
const router = (0, express_1.Router)();
router.use(auth_1.authenticateToken);
router.get('/versoes', avaliacaoController_1.avaliacaoController.listVersoes.bind(avaliacaoController_1.avaliacaoController));
router.get('/versoes/ativa', avaliacaoController_1.avaliacaoController.getVersaoAtiva.bind(avaliacaoController_1.avaliacaoController));
router.get('/versoes/:id', avaliacaoController_1.avaliacaoController.getVersaoById.bind(avaliacaoController_1.avaliacaoController));
router.post('/versoes', adminAuth_1.requireAdmin, avaliacaoController_1.avaliacaoController.createVersao.bind(avaliacaoController_1.avaliacaoController));
router.put('/versoes/:id', adminAuth_1.requireAdmin, avaliacaoController_1.avaliacaoController.updateVersao.bind(avaliacaoController_1.avaliacaoController));
router.get('/versoes/:id/perguntas', avaliacaoController_1.avaliacaoController.listPerguntas.bind(avaliacaoController_1.avaliacaoController));
router.post('/versoes/:id/perguntas', adminAuth_1.requireAdmin, avaliacaoController_1.avaliacaoController.createPergunta.bind(avaliacaoController_1.avaliacaoController));
router.put('/perguntas/:id', adminAuth_1.requireAdmin, avaliacaoController_1.avaliacaoController.updatePergunta.bind(avaliacaoController_1.avaliacaoController));
router.delete('/perguntas/:id', adminAuth_1.requireAdmin, avaliacaoController_1.avaliacaoController.deletePergunta.bind(avaliacaoController_1.avaliacaoController));
exports.default = router;
//# sourceMappingURL=avaliacaoRoutes.js.map