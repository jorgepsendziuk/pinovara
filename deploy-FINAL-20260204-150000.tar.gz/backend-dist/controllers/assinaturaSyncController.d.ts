import { Request, Response } from 'express';
export declare const assinaturaSyncController: {
    sync(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    listODKAvailable(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
};
//# sourceMappingURL=assinaturaSyncController.d.ts.map