"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.capacitacaoController = void 0;
const capacitacaoService_1 = __importDefault(require("../services/capacitacaoService"));
const api_1 = require("../types/api");
const auditService_1 = __importDefault(require("../services/auditService"));
const audit_1 = require("../types/audit");
class CapacitacaoController {
    async list(req, res) {
        try {
            const userPermissions = req.userPermissions;
            const canSeeAll = userPermissions?.canAccessAll || false;
            const filters = {
                id_qualificacao: req.query.id_qualificacao ? parseInt(req.query.id_qualificacao) : undefined,
                status: req.query.status,
                id_organizacao: req.query.id_organizacao ? parseInt(req.query.id_organizacao) : undefined,
                created_by: req.query.created_by ? parseInt(req.query.created_by) : undefined,
                data_inicio: req.query.data_inicio ? new Date(req.query.data_inicio) : undefined,
                data_fim: req.query.data_fim ? new Date(req.query.data_fim) : undefined,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) :
                    req.query.pageSize ? parseInt(req.query.pageSize) : 10
            };
            if (!canSeeAll && req.user?.id) {
                filters.userId = req.user.id;
                filters.filterByUser = true;
            }
            const result = await capacitacaoService_1.default.list(filters);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: result,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getById(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await capacitacaoService_1.default.getById(id);
            if (!capacitacao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const userPermissions = req.userPermissions;
            const canSeeAll = userPermissions?.canAccessAll || false;
            if (!canSeeAll) {
                const isCriador = capacitacao.created_by === req.user?.id;
                const capacitacaoData = capacitacao;
                const isMembroEquipe = capacitacaoData.equipe_tecnica?.some((membro) => membro.id_tecnico === req.user?.id) || false;
                if (!isCriador && !isMembroEquipe) {
                    res.status(api_1.HttpStatus.FORBIDDEN).json({
                        success: false,
                        error: {
                            message: 'Acesso negado. Você só pode visualizar capacitações que criou ou está vinculado.',
                            statusCode: api_1.HttpStatus.FORBIDDEN
                        },
                        timestamp: new Date().toISOString()
                    });
                    return;
                }
            }
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: capacitacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async create(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await capacitacaoService_1.default.create(req.body, req.user.id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.CREATE,
                entity: 'capacitacao',
                entityId: capacitacao.id?.toString(),
                newData: capacitacao,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Capacitação criada com sucesso',
                data: capacitacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async update(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const oldData = await capacitacaoService_1.default.getById(id);
            if (!oldData) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const userPermissions = req.userPermissions;
            const isAdmin = userPermissions?.isAdmin || false;
            if (!isAdmin) {
                const isCriador = oldData.created_by === req.user?.id;
                const capacitacaoData = oldData;
                const isMembroEquipe = capacitacaoData.equipe_tecnica?.some((membro) => membro.id_tecnico === req.user?.id) || false;
                if (!isCriador && !isMembroEquipe) {
                    res.status(api_1.HttpStatus.FORBIDDEN).json({
                        success: false,
                        error: {
                            message: 'Acesso negado. Apenas administradores, o criador e a equipe técnica podem editar esta capacitação.',
                            statusCode: api_1.HttpStatus.FORBIDDEN
                        },
                        timestamp: new Date().toISOString()
                    });
                    return;
                }
            }
            const capacitacao = await capacitacaoService_1.default.update(id, req.body, req.user.id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.UPDATE,
                entity: 'capacitacao',
                entityId: capacitacao.id?.toString(),
                oldData,
                newData: capacitacao,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Capacitação atualizada com sucesso',
                data: capacitacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async delete(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const oldData = await capacitacaoService_1.default.getById(id);
            if (!oldData) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const userPermissions = req.userPermissions;
            const isAdmin = userPermissions?.isAdmin || false;
            if (!isAdmin) {
                const isCriador = oldData.created_by === req.user?.id;
                const capacitacaoData = oldData;
                const isMembroEquipe = capacitacaoData.equipe_tecnica?.some((membro) => membro.id_tecnico === req.user?.id) || false;
                if (!isCriador && !isMembroEquipe) {
                    res.status(api_1.HttpStatus.FORBIDDEN).json({
                        success: false,
                        error: {
                            message: 'Acesso negado. Apenas administradores, o criador e a equipe técnica podem excluir esta capacitação.',
                            statusCode: api_1.HttpStatus.FORBIDDEN
                        },
                        timestamp: new Date().toISOString()
                    });
                    return;
                }
            }
            await capacitacaoService_1.default.delete(id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.DELETE,
                entity: 'capacitacao',
                entityId: id.toString(),
                oldData,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Capacitação excluída com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listInscricoes(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const inscricoes = await capacitacaoService_1.default.listInscricoes(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: inscricoes,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async createInscricao(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const inscricao = await capacitacaoService_1.default.createInscricao(id, req.body, req.user.id);
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Inscrição criada com sucesso',
                data: inscricao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async updateInscricao(req, res) {
        try {
            const id = parseInt(req.params.id);
            const inscricaoId = parseInt(req.params.inscricaoId);
            if (isNaN(id) || isNaN(inscricaoId)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const inscricao = await capacitacaoService_1.default.updateInscricao(id, inscricaoId, req.body);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Inscrição atualizada com sucesso',
                data: inscricao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async deleteInscricao(req, res) {
        try {
            const id = parseInt(req.params.id);
            const inscricaoId = parseInt(req.params.inscricaoId);
            if (isNaN(id) || isNaN(inscricaoId)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            await capacitacaoService_1.default.deleteInscricao(id, inscricaoId);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Inscrição excluída com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listPresencas(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const presencas = await capacitacaoService_1.default.listPresencas(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: presencas,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async createPresenca(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const presenca = await capacitacaoService_1.default.createPresenca(id, req.body, req.user.id);
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Presença registrada com sucesso',
                data: presenca,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async updatePresenca(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            const idPresenca = parseInt(req.params.presencaId);
            if (isNaN(id) || isNaN(idPresenca)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const presenca = await capacitacaoService_1.default.updatePresenca(id, idPresenca, req.body);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Presença atualizada com sucesso',
                data: presenca,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async deletePresenca(req, res) {
        try {
            const id = parseInt(req.params.id);
            const idPresenca = parseInt(req.params.presencaId);
            if (isNaN(id) || isNaN(idPresenca)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            await capacitacaoService_1.default.deletePresenca(id, idPresenca);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Presença excluída com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async addTecnico(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            const { id_tecnico } = req.body;
            if (isNaN(id) || !id_tecnico) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID da capacitação e ID do técnico são obrigatórios',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            await capacitacaoService_1.default.addTecnico(id, id_tecnico, req.user.id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Técnico adicionado à equipe com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async removeTecnico(req, res) {
        try {
            const id = parseInt(req.params.id);
            const idTecnico = parseInt(req.params.idTecnico);
            if (isNaN(id) || isNaN(idTecnico)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'IDs inválidos',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            await capacitacaoService_1.default.removeTecnico(id, idTecnico);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Técnico removido da equipe com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listTecnicos(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const tecnicos = await capacitacaoService_1.default.listTecnicos(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: tecnicos,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    handleError(error, res) {
        console.error('❌ [CapacitacaoController] Error:', error);
        if (error instanceof Error && 'statusCode' in error) {
            const apiError = error;
            res.status(apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: apiError.message || 'Erro ao processar requisição',
                    code: apiError.code,
                    statusCode: apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
        else {
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro interno do servidor',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async updateValidacao(req, res) {
        try {
            const id = parseInt(req.params.id);
            const { validacao_status, validacao_obs, validacao_usuario } = req.body;
            const userPermissions = req.userPermissions;
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (!userPermissions?.isCoordinator && !userPermissions?.isAdmin) {
                res.status(api_1.HttpStatus.FORBIDDEN).json({
                    success: false,
                    error: {
                        message: 'Apenas coordenadores e administradores podem validar capacitações',
                        statusCode: api_1.HttpStatus.FORBIDDEN
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const dadosValidacao = {
                validacao_status: validacao_status || null,
                validacao_obs: validacao_obs || null,
                validacao_usuario: validacao_usuario || req.user?.id || null,
                validacao_data: new Date()
            };
            const capacitacao = await capacitacaoService_1.default.updateValidacao(id, dadosValidacao);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.UPDATE,
                entity: 'capacitacao',
                entityId: id.toString(),
                userId: req.user.id,
                newData: dadosValidacao,
                req
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Validação atualizada com sucesso',
                data: capacitacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getHistoricoValidacao(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const historico = await capacitacaoService_1.default.getHistoricoValidacao(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: historico,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
}
exports.capacitacaoController = new CapacitacaoController();
//# sourceMappingURL=capacitacaoController.js.map