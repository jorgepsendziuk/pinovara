import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
declare class AvaliacaoController {
    listVersoes(req: AuthRequest, res: Response): Promise<void>;
    getVersaoAtiva(req: AuthRequest, res: Response): Promise<void>;
    getVersaoById(req: AuthRequest, res: Response): Promise<void>;
    createVersao(req: AuthRequest, res: Response): Promise<void>;
    updateVersao(req: AuthRequest, res: Response): Promise<void>;
    listPerguntas(req: AuthRequest, res: Response): Promise<void>;
    createPergunta(req: AuthRequest, res: Response): Promise<void>;
    updatePergunta(req: AuthRequest, res: Response): Promise<void>;
    deletePergunta(req: AuthRequest, res: Response): Promise<void>;
    listAvaliacoes(req: AuthRequest, res: Response): Promise<void>;
    getEstatisticas(req: AuthRequest, res: Response): Promise<void>;
    private handleError;
}
export declare const avaliacaoController: AvaliacaoController;
export {};
//# sourceMappingURL=avaliacaoController.d.ts.map