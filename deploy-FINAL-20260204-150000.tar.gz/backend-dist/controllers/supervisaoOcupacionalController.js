"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supervisaoOcupacionalController = void 0;
const supervisaoOcupacionalService_1 = require("../services/supervisaoOcupacionalService");
const ApiError_1 = require("../utils/ApiError");
const api_1 = require("../types/api");
const familiaFieldMapper_1 = require("../utils/familiaFieldMapper");
class SupervisaoOcupacionalController {
    async getDashboard(req, res) {
        try {
            const dashboard = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getDashboard();
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: dashboard,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listGlebas(req, res) {
        try {
            const filters = {
                estado: req.query.estado ? parseInt(req.query.estado) : undefined,
                municipio: req.query.municipio ? parseInt(req.query.municipio) : undefined,
                search: req.query.search,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) : 10,
            };
            const result = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.listGlebas(filters);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: result,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getGlebaById(req, res) {
        try {
            const id = parseInt(req.params.id);
            const gleba = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getGlebaById(id);
            if (!gleba) {
                throw new ApiError_1.ApiError({
                    message: 'Gleba não encontrada',
                    statusCode: api_1.HttpStatus.NOT_FOUND
                });
            }
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: gleba,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async createGleba(req, res) {
        try {
            const gleba = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.createGleba(req.body);
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                data: gleba,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async updateGleba(req, res) {
        try {
            const id = parseInt(req.params.id);
            const gleba = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.updateGleba(id, req.body);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: gleba,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async deleteGleba(req, res) {
        try {
            const id = parseInt(req.params.id);
            await supervisaoOcupacionalService_1.supervisaoOcupacionalService.deleteGleba(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Gleba removida com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listFamilias(req, res) {
        try {
            const userPermissions = req.userPermissions;
            const userId = req.user?.id;
            const filters = {
                gleba: req.query.gleba ? parseInt(req.query.gleba) : undefined,
                estado: req.query.estado ? parseInt(req.query.estado) : undefined,
                municipio: req.query.municipio ? parseInt(req.query.municipio) : undefined,
                validacao: req.query.validacao ? parseInt(req.query.validacao) : undefined,
                tecnico: req.query.tecnico ? parseInt(req.query.tecnico) : undefined,
                aceitou_visita: req.query.aceitou_visita ? parseInt(req.query.aceitou_visita) : undefined,
                quilombo: req.query.quilombo,
                search: req.query.search,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) : 10,
            };
            if (userPermissions?.canViewOwnOnly && !userPermissions.isSystemAdmin && !userPermissions.isModuleAdmin) {
                filters.tecnico = userId;
            }
            const result = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.listFamilias(filters);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: result,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getFamiliaById(req, res) {
        try {
            const id = parseInt(req.params.id);
            console.log('[DEBUG] Controller - Buscando família ID:', id);
            const familia = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getFamiliaById(id);
            if (!familia) {
                throw new ApiError_1.ApiError({
                    message: 'Família não encontrada',
                    statusCode: api_1.HttpStatus.NOT_FOUND
                });
            }
            const familiaAny = familia;
            console.log('[DEBUG] Controller - Família encontrada no banco:', {
                id: familia.id,
                iuf_ocup_nome: familiaAny.iuf_ocup_nome,
                iuf_ocup_cpf: familiaAny.iuf_ocup_cpf,
                num_imovel: familiaAny.num_imovel,
                aceitou_visita: familiaAny.aceitou_visita
            });
            const familiaMapped = (0, familiaFieldMapper_1.mapFamiliaFromDB)(familia);
            console.log('[DEBUG] Família mapeada:', {
                id: familiaMapped.id,
                iuf_nome_ocupante: familiaMapped.iuf_nome_ocupante,
                g00_0_q1_2: familiaMapped.g00_0_q1_2,
                i_q1_10: familiaMapped.i_q1_10,
                i_q1_17: familiaMapped.i_q1_17
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: familiaMapped,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async validateFamilia(req, res) {
        try {
            const id = parseInt(req.params.id);
            const { validacao, obs_validacao } = req.body;
            const userId = req.user?.id;
            const userPermissions = req.userPermissions;
            if (!userPermissions?.canValidate) {
                throw new ApiError_1.ApiError({
                    message: 'Acesso negado. Apenas administradores e coordenadores podem validar famílias.',
                    statusCode: api_1.HttpStatus.FORBIDDEN
                });
            }
            const familiaExistente = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getFamiliaById(id);
            if (!familiaExistente) {
                throw new ApiError_1.ApiError({
                    message: 'Família não encontrada',
                    statusCode: api_1.HttpStatus.NOT_FOUND
                });
            }
            const familia = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.validateFamilia(id, {
                validacao,
                obs_validacao,
                tecnico: userId
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: familia,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async updateFamilia(req, res) {
        try {
            const id = parseInt(req.params.id);
            const userPermissions = req.userPermissions;
            if (!userPermissions?.canEdit) {
                throw new ApiError_1.ApiError({
                    message: 'Acesso negado. Apenas administradores e técnicos podem editar famílias.',
                    statusCode: api_1.HttpStatus.FORBIDDEN
                });
            }
            const familiaExistente = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getFamiliaById(id);
            if (!familiaExistente) {
                throw new ApiError_1.ApiError({
                    message: 'Família não encontrada',
                    statusCode: api_1.HttpStatus.NOT_FOUND
                });
            }
            if (userPermissions.isTechnician && !userPermissions.isSystemAdmin && !userPermissions.isModuleAdmin) {
                if (familiaExistente.tecnico !== userPermissions.userId) {
                    throw new ApiError_1.ApiError({
                        message: 'Acesso negado. Você só pode editar famílias atribuídas a você.',
                        statusCode: api_1.HttpStatus.FORBIDDEN
                    });
                }
            }
            const dataMapped = (0, familiaFieldMapper_1.mapFamiliaToDB)(req.body);
            const familia = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.updateFamilia(id, dataMapped);
            const familiaMapped = (0, familiaFieldMapper_1.mapFamiliaFromDB)(familia);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: familiaMapped,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listODKAvailable(req, res) {
        try {
            const result = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.listODKAvailable();
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: result,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async syncFromODK(req, res) {
        try {
            const { instanceIds } = req.body;
            const userEmail = req.user?.email || 'sistema';
            const result = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.syncFromODK(instanceIds || [], userEmail);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: result,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getEstados(req, res) {
        try {
            const estados = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getEstados();
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: estados,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getMunicipios(req, res) {
        try {
            const estadoId = req.params.estadoId ? parseInt(req.params.estadoId) : undefined;
            const municipios = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getMunicipios(estadoId);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: municipios,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getTecnicos(req, res) {
        try {
            const tecnicos = await supervisaoOcupacionalService_1.supervisaoOcupacionalService.getTecnicos();
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: tecnicos,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    handleError(error, res) {
        console.error('Erro no controller:', error);
        if (error instanceof ApiError_1.ApiError) {
            res.status(error.statusCode).json({
                success: false,
                error: error.message,
                timestamp: new Date().toISOString()
            });
        }
        else {
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: error.message || 'Erro interno do servidor',
                timestamp: new Date().toISOString()
            });
        }
    }
}
exports.supervisaoOcupacionalController = new SupervisaoOcupacionalController();
//# sourceMappingURL=supervisaoOcupacionalController.js.map