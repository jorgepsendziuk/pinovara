"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.qualificacaoController = void 0;
const qualificacaoService_1 = __importDefault(require("../services/qualificacaoService"));
const api_1 = require("../types/api");
const auditService_1 = __importDefault(require("../services/auditService"));
const audit_1 = require("../types/audit");
class QualificacaoController {
    async list(req, res) {
        try {
            const userPermissions = req.userPermissions;
            const canSeeAll = userPermissions?.canAccessAll || false;
            const filters = {
                titulo: req.query.titulo,
                ativo: req.query.ativo === 'true' ? true : req.query.ativo === 'false' ? false : undefined,
                id_organizacao: req.query.id_organizacao ? parseInt(req.query.id_organizacao) : undefined,
                id_instrutor: req.query.id_instrutor ? parseInt(req.query.id_instrutor) : undefined,
                created_by: req.query.created_by ? parseInt(req.query.created_by) : undefined,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) :
                    req.query.pageSize ? parseInt(req.query.pageSize) : 10
            };
            if (!canSeeAll && req.user?.id) {
                filters.userId = req.user.id;
                filters.filterByUser = true;
            }
            const result = await qualificacaoService_1.default.list(filters);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: result,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getById(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const qualificacao = await qualificacaoService_1.default.getById(id);
            if (!qualificacao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Qualificação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const userPermissions = req.userPermissions;
            const canSeeAll = userPermissions?.canAccessAll || false;
            const isPadrao = id === 1 || id === 2 || id === 3;
            if (!canSeeAll) {
                const isCriador = qualificacao.created_by === req.user?.id;
                const qualificacaoData = qualificacao;
                const isMembroEquipe = qualificacaoData.equipe_tecnica?.some((membro) => membro.id_tecnico === req.user?.id) || false;
                if (!isCriador && !isMembroEquipe && !isPadrao) {
                    res.status(api_1.HttpStatus.FORBIDDEN).json({
                        success: false,
                        error: {
                            message: 'Acesso negado. Você só pode visualizar qualificações que criou, está vinculado ou as qualificações padrão do sistema.',
                            statusCode: api_1.HttpStatus.FORBIDDEN
                        },
                        timestamp: new Date().toISOString()
                    });
                    return;
                }
            }
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: qualificacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async create(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const qualificacao = await qualificacaoService_1.default.create(req.body, req.user.id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.CREATE,
                entity: 'qualificacao',
                entityId: qualificacao.id?.toString(),
                newData: qualificacao,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Qualificação criada com sucesso',
                data: qualificacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async update(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const oldData = await qualificacaoService_1.default.getById(id);
            if (!oldData) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Qualificação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const userPermissions = req.userPermissions;
            const isAdmin = userPermissions?.isAdmin || false;
            if ((id === 1 || id === 2 || id === 3) && !isAdmin) {
                res.status(api_1.HttpStatus.FORBIDDEN).json({
                    success: false,
                    error: {
                        message: 'Acesso negado. Apenas administradores podem editar qualificações padrão do sistema.',
                        statusCode: api_1.HttpStatus.FORBIDDEN
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (!isAdmin) {
                const isCriador = oldData.created_by === req.user?.id;
                const qualificacaoData = oldData;
                const isMembroEquipe = qualificacaoData.equipe_tecnica?.some((membro) => membro.id_tecnico === req.user?.id) || false;
                if (!isCriador && !isMembroEquipe) {
                    res.status(api_1.HttpStatus.FORBIDDEN).json({
                        success: false,
                        error: {
                            message: 'Acesso negado. Apenas administradores, o criador e a equipe técnica podem editar esta qualificação.',
                            statusCode: api_1.HttpStatus.FORBIDDEN
                        },
                        timestamp: new Date().toISOString()
                    });
                    return;
                }
            }
            const qualificacao = await qualificacaoService_1.default.update(id, req.body, req.user.id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.UPDATE,
                entity: 'qualificacao',
                entityId: qualificacao.id?.toString(),
                oldData,
                newData: qualificacao,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Qualificação atualizada com sucesso',
                data: qualificacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async delete(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const oldData = await qualificacaoService_1.default.getById(id);
            if (!oldData) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Qualificação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (id === 1 || id === 2 || id === 3) {
                res.status(api_1.HttpStatus.FORBIDDEN).json({
                    success: false,
                    error: {
                        message: 'Não é possível excluir qualificações padrão do sistema.',
                        statusCode: api_1.HttpStatus.FORBIDDEN
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const userPermissions = req.userPermissions;
            const isAdmin = userPermissions?.isAdmin || false;
            if (!isAdmin) {
                const isCriador = oldData.created_by === req.user?.id;
                const qualificacaoData = oldData;
                const isMembroEquipe = qualificacaoData.equipe_tecnica?.some((membro) => membro.id_tecnico === req.user?.id) || false;
                if (!isCriador && !isMembroEquipe) {
                    res.status(api_1.HttpStatus.FORBIDDEN).json({
                        success: false,
                        error: {
                            message: 'Acesso negado. Apenas administradores, o criador e a equipe técnica podem excluir esta qualificação.',
                            statusCode: api_1.HttpStatus.FORBIDDEN
                        },
                        timestamp: new Date().toISOString()
                    });
                    return;
                }
            }
            await qualificacaoService_1.default.delete(id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.DELETE,
                entity: 'qualificacao',
                entityId: id.toString(),
                oldData,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Qualificação excluída com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async addTecnico(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            const { id_tecnico } = req.body;
            if (isNaN(id) || !id_tecnico) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID da qualificação e ID do técnico são obrigatórios',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            await qualificacaoService_1.default.addTecnico(id, id_tecnico, req.user.id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Técnico adicionado à equipe com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async removeTecnico(req, res) {
        try {
            const id = parseInt(req.params.id);
            const idTecnico = parseInt(req.params.idTecnico);
            if (isNaN(id) || isNaN(idTecnico)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'IDs inválidos',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            await qualificacaoService_1.default.removeTecnico(id, idTecnico);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Técnico removido da equipe com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listTecnicos(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const tecnicos = await qualificacaoService_1.default.listTecnicos(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: tecnicos,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listTecnicosDisponiveis(req, res) {
        try {
            const userPermissions = req.userPermissions;
            const isAdmin = userPermissions?.isAdmin || false;
            const isSupervisor = userPermissions?.isSupervisor || false;
            const isCoordinator = userPermissions?.isCoordinator || false;
            const isTecnico = userPermissions?.isTechnician || false;
            if (!isAdmin && !isSupervisor && !isCoordinator && !isTecnico) {
                res.status(api_1.HttpStatus.FORBIDDEN).json({
                    success: false,
                    error: {
                        message: 'Acesso negado. Apenas técnicos, coordenadores, supervisores ou administradores podem acessar esta funcionalidade.',
                        statusCode: api_1.HttpStatus.FORBIDDEN
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const tecnicos = await qualificacaoService_1.default.listTecnicosDisponiveis();
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: tecnicos,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    handleError(error, res) {
        console.error('❌ [QualificacaoController] Error:', error);
        if (error instanceof Error && 'statusCode' in error) {
            const apiError = error;
            res.status(apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: apiError.message || 'Erro ao processar requisição',
                    code: apiError.code,
                    statusCode: apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
        else {
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: error instanceof Error ? error.message : 'Erro interno do servidor',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async updateValidacao(req, res) {
        try {
            const id = parseInt(req.params.id);
            const { validacao_status, validacao_obs, validacao_usuario } = req.body;
            const userPermissions = req.userPermissions;
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (!userPermissions?.isCoordinator && !userPermissions?.isAdmin) {
                res.status(api_1.HttpStatus.FORBIDDEN).json({
                    success: false,
                    error: {
                        message: 'Apenas coordenadores e administradores podem validar qualificações',
                        statusCode: api_1.HttpStatus.FORBIDDEN
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const dadosValidacao = {
                validacao_status: validacao_status || null,
                validacao_obs: validacao_obs || null,
                validacao_usuario: validacao_usuario || req.user?.id || null,
                validacao_data: new Date()
            };
            const qualificacao = await qualificacaoService_1.default.updateValidacao(id, dadosValidacao);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.UPDATE,
                entity: 'qualificacao',
                entityId: id.toString(),
                userId: req.user.id,
                newData: dadosValidacao,
                req
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Validação atualizada com sucesso',
                data: qualificacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getHistoricoValidacao(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const historico = await qualificacaoService_1.default.getHistoricoValidacao(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: historico,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
}
exports.qualificacaoController = new QualificacaoController();
//# sourceMappingURL=qualificacaoController.js.map