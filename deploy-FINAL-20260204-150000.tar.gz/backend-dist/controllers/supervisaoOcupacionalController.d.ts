import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
declare class SupervisaoOcupacionalController {
    getDashboard(req: AuthRequest, res: Response): Promise<void>;
    listGlebas(req: AuthRequest, res: Response): Promise<void>;
    getGlebaById(req: AuthRequest, res: Response): Promise<void>;
    createGleba(req: AuthRequest, res: Response): Promise<void>;
    updateGleba(req: AuthRequest, res: Response): Promise<void>;
    deleteGleba(req: AuthRequest, res: Response): Promise<void>;
    listFamilias(req: AuthRequest, res: Response): Promise<void>;
    getFamiliaById(req: AuthRequest, res: Response): Promise<void>;
    validateFamilia(req: AuthRequest, res: Response): Promise<void>;
    updateFamilia(req: AuthRequest, res: Response): Promise<void>;
    listODKAvailable(req: AuthRequest, res: Response): Promise<void>;
    syncFromODK(req: AuthRequest, res: Response): Promise<void>;
    getEstados(req: AuthRequest, res: Response): Promise<void>;
    getMunicipios(req: AuthRequest, res: Response): Promise<void>;
    getTecnicos(req: AuthRequest, res: Response): Promise<void>;
    private handleError;
}
export declare const supervisaoOcupacionalController: SupervisaoOcupacionalController;
export {};
//# sourceMappingURL=supervisaoOcupacionalController.d.ts.map