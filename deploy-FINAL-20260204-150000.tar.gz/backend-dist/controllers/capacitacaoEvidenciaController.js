"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadEvidencia = exports.capacitacaoEvidenciaController = void 0;
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const client_1 = require("@prisma/client");
const api_1 = require("../types/api");
const prisma = new client_1.PrismaClient();
const UPLOAD_DIR = process.env.NODE_ENV === 'production'
    ? '/var/pinovara/shared/uploads/capacitacao/evidencias'
    : '/Users/jorgepsendziuk/Documents/pinovara/uploads/capacitacao/evidencias';
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        try {
            if (!fs_1.default.existsSync(UPLOAD_DIR)) {
                fs_1.default.mkdirSync(UPLOAD_DIR, { recursive: true, mode: 0o755 });
            }
            fs_1.default.accessSync(UPLOAD_DIR, fs_1.default.constants.W_OK);
            cb(null, UPLOAD_DIR);
        }
        catch (error) {
            console.error(`Erro ao configurar diretório de upload ${UPLOAD_DIR}:`, error);
            cb(new Error(`Sem permissão para escrever no diretório de upload. Contate o administrador do sistema.`), '');
        }
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path_1.default.extname(file.originalname));
    }
});
const fileFilter = (req, file, cb) => {
    const allowedTypes = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'image/jpg'
    ];
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    }
    else {
        cb(new Error('Tipo de arquivo não permitido. Apenas PDF e imagens são aceitos.'));
    }
};
const upload = (0, multer_1.default)({
    storage,
    fileFilter,
    limits: {
        fileSize: 50 * 1024 * 1024
    }
});
class CapacitacaoEvidenciaController {
    async uploadEvidencia(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const idCapacitacao = parseInt(req.params.id);
            if (isNaN(idCapacitacao)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const file = req.file;
            if (!file) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Nenhum arquivo foi enviado',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await prisma.capacitacao.findUnique({
                where: { id: idCapacitacao }
            });
            if (!capacitacao) {
                fs_1.default.unlinkSync(file.path);
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const tipo = req.body.tipo || (file.mimetype.startsWith('image/') ? 'foto' : 'outro');
            const evidencia = await prisma.capacitacao_evidencia.create({
                data: {
                    id_capacitacao: idCapacitacao,
                    tipo: tipo,
                    nome_arquivo: file.filename,
                    caminho_arquivo: path_1.default.join(UPLOAD_DIR, file.filename),
                    descricao: req.body.descricao || null,
                    data_evidencia: req.body.data_evidencia ? new Date(req.body.data_evidencia) : null,
                    local_evidencia: req.body.local_evidencia || null,
                    uploaded_by: req.user.id
                }
            });
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Evidência enviada com sucesso',
                data: evidencia,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            console.error('❌ [CapacitacaoEvidenciaController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao fazer upload de evidência',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async listEvidencias(req, res) {
        try {
            const idCapacitacao = parseInt(req.params.id);
            const tipo = req.query.tipo;
            if (isNaN(idCapacitacao)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const where = { id_capacitacao: idCapacitacao };
            if (tipo) {
                where.tipo = tipo;
            }
            const evidencias = await prisma.capacitacao_evidencia.findMany({
                where,
                orderBy: { created_at: 'desc' }
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: evidencias,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            console.error('❌ [CapacitacaoEvidenciaController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao listar evidências',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async downloadEvidencia(req, res) {
        try {
            const idCapacitacao = parseInt(req.params.id);
            const evidenciaId = parseInt(req.params.evidenciaId);
            if (isNaN(idCapacitacao) || isNaN(evidenciaId)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const evidencia = await prisma.capacitacao_evidencia.findFirst({
                where: {
                    id: evidenciaId,
                    id_capacitacao: idCapacitacao
                }
            });
            if (!evidencia) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Evidência não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (!fs_1.default.existsSync(evidencia.caminho_arquivo)) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Arquivo não encontrado no servidor',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const mimeType = evidencia.caminho_arquivo.endsWith('.pdf')
                ? 'application/pdf'
                : 'image/jpeg';
            res.setHeader('Content-Disposition', `inline; filename="${evidencia.nome_arquivo}"`);
            res.setHeader('Content-Type', mimeType);
            res.sendFile(path_1.default.resolve(evidencia.caminho_arquivo));
        }
        catch (error) {
            console.error('❌ [CapacitacaoEvidenciaController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao fazer download da evidência',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async deleteEvidencia(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const idCapacitacao = parseInt(req.params.id);
            const evidenciaId = parseInt(req.params.evidenciaId);
            if (isNaN(idCapacitacao) || isNaN(evidenciaId)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const evidencia = await prisma.capacitacao_evidencia.findFirst({
                where: {
                    id: evidenciaId,
                    id_capacitacao: idCapacitacao
                }
            });
            if (!evidencia) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Evidência não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (fs_1.default.existsSync(evidencia.caminho_arquivo)) {
                fs_1.default.unlinkSync(evidencia.caminho_arquivo);
            }
            await prisma.capacitacao_evidencia.delete({
                where: { id: evidenciaId }
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Evidência excluída com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            console.error('❌ [CapacitacaoEvidenciaController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao excluir evidência',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
}
exports.capacitacaoEvidenciaController = new CapacitacaoEvidenciaController();
exports.uploadEvidencia = upload.single('arquivo');
//# sourceMappingURL=capacitacaoEvidenciaController.js.map