import { Request, Response } from 'express';
export declare const odkSyncController: {
    syncAll(req: Request, res: Response): Promise<void>;
    getStats(req: Request, res: Response): Promise<void>;
};
//# sourceMappingURL=odkSyncController.d.ts.map