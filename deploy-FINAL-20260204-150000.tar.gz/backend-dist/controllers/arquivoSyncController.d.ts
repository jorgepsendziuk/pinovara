import { Request, Response } from 'express';
export declare const arquivoSyncController: {
    syncFromODK(req: Request, res: Response): Promise<void>;
    listODKAvailable(req: Request, res: Response): Promise<void>;
};
//# sourceMappingURL=arquivoSyncController.d.ts.map