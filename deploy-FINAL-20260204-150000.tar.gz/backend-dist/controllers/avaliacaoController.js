"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.avaliacaoController = void 0;
const avaliacaoService_1 = __importDefault(require("../services/avaliacaoService"));
const api_1 = require("../types/api");
const auditService_1 = __importDefault(require("../services/auditService"));
const audit_1 = require("../types/audit");
class AvaliacaoController {
    async listVersoes(req, res) {
        try {
            const ativo = req.query.ativo === 'true' ? true : req.query.ativo === 'false' ? false : undefined;
            const versoes = await avaliacaoService_1.default.listVersoes(ativo);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: versoes,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getVersaoAtiva(req, res) {
        try {
            const versao = await avaliacaoService_1.default.getVersaoAtiva();
            if (!versao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Nenhuma versão ativa encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: versao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getVersaoById(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const versao = await avaliacaoService_1.default.getVersaoById(id);
            if (!versao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Versão não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: versao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async createVersao(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const versao = await avaliacaoService_1.default.createVersao(req.body, req.user.id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.CREATE,
                entity: 'avaliacao_versao',
                entityId: versao.id?.toString(),
                newData: versao,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Versão de avaliação criada com sucesso',
                data: versao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async updateVersao(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const oldData = await avaliacaoService_1.default.getVersaoById(id);
            if (!oldData) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Versão não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const versao = await avaliacaoService_1.default.updateVersao(id, req.body, req.user.id);
            await auditService_1.default.createLog({
                action: audit_1.AuditAction.UPDATE,
                entity: 'avaliacao_versao',
                entityId: versao.id?.toString(),
                oldData,
                newData: versao,
                userId: req.user.id,
                req
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Versão de avaliação atualizada com sucesso',
                data: versao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listPerguntas(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const perguntas = await avaliacaoService_1.default.listPerguntas(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: perguntas,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async createPergunta(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const pergunta = await avaliacaoService_1.default.createPergunta(id, req.body);
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Pergunta criada com sucesso',
                data: pergunta,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async updatePergunta(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const pergunta = await avaliacaoService_1.default.updatePergunta(id, req.body);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Pergunta atualizada com sucesso',
                data: pergunta,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async deletePergunta(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            await avaliacaoService_1.default.deletePergunta(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Pergunta excluída com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listAvaliacoes(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const avaliacoes = await avaliacaoService_1.default.listAvaliacoes(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: avaliacoes,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getEstatisticas(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const estatisticas = await avaliacaoService_1.default.getEstatisticas(id);
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: estatisticas,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    handleError(error, res) {
        console.error('❌ [AvaliacaoController] Error:', error);
        if (error instanceof Error && 'statusCode' in error) {
            const apiError = error;
            res.status(apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: apiError.message || 'Erro ao processar requisição',
                    code: apiError.code,
                    statusCode: apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
        else {
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro interno do servidor',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
}
exports.avaliacaoController = new AvaliacaoController();
//# sourceMappingURL=avaliacaoController.js.map