import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
declare class CapacitacaoMaterialController {
    uploadMaterial(req: AuthRequest, res: Response): Promise<void>;
    listMateriais(req: AuthRequest, res: Response): Promise<void>;
    downloadMaterial(req: AuthRequest, res: Response): Promise<void>;
    deleteMaterial(req: AuthRequest, res: Response): Promise<void>;
}
export declare const capacitacaoMaterialController: CapacitacaoMaterialController;
export declare const uploadMaterial: import("express").RequestHandler<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
export {};
//# sourceMappingURL=capacitacaoMaterialController.d.ts.map