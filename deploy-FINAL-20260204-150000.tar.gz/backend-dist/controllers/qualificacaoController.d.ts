import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
declare class QualificacaoController {
    list(req: AuthRequest, res: Response): Promise<void>;
    getById(req: AuthRequest, res: Response): Promise<void>;
    create(req: AuthRequest, res: Response): Promise<void>;
    update(req: AuthRequest, res: Response): Promise<void>;
    delete(req: AuthRequest, res: Response): Promise<void>;
    addTecnico(req: AuthRequest, res: Response): Promise<void>;
    removeTecnico(req: AuthRequest, res: Response): Promise<void>;
    listTecnicos(req: AuthRequest, res: Response): Promise<void>;
    listTecnicosDisponiveis(req: AuthRequest, res: Response): Promise<void>;
    private handleError;
    updateValidacao(req: AuthRequest, res: Response): Promise<void>;
    getHistoricoValidacao(req: AuthRequest, res: Response): Promise<void>;
}
export declare const qualificacaoController: QualificacaoController;
export {};
//# sourceMappingURL=qualificacaoController.d.ts.map