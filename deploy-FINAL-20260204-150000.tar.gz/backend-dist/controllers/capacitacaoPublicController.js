"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.capacitacaoPublicController = void 0;
const capacitacaoService_1 = __importDefault(require("../services/capacitacaoService"));
const avaliacaoService_1 = __importDefault(require("../services/avaliacaoService"));
const api_1 = require("../types/api");
const client_1 = require("@prisma/client");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const prisma = new client_1.PrismaClient();
class CapacitacaoPublicController {
    async getByLinkInscricao(req, res) {
        try {
            const { linkInscricao } = req.params;
            if (!linkInscricao) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Link de inscrição é obrigatório',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await capacitacaoService_1.default.getByLinkInscricao(linkInscricao);
            if (!capacitacao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: capacitacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async createInscricaoPublica(req, res) {
        try {
            const { linkInscricao } = req.params;
            if (!linkInscricao) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Link de inscrição é obrigatório',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await capacitacaoService_1.default.getByLinkInscricao(linkInscricao);
            if (!capacitacao || !capacitacao.id) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const inscricao = await capacitacaoService_1.default.createInscricao(capacitacao.id, req.body);
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Inscrição realizada com sucesso',
                data: inscricao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async getByLinkAvaliacao(req, res) {
        try {
            const { linkAvaliacao } = req.params;
            if (!linkAvaliacao) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Link de avaliação é obrigatório',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await capacitacaoService_1.default.getByLinkAvaliacao(linkAvaliacao);
            if (!capacitacao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const versaoAtiva = await avaliacaoService_1.default.getVersaoAtiva();
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: {
                    capacitacao,
                    versao_avaliacao: versaoAtiva
                },
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async createAvaliacaoPublica(req, res) {
        try {
            const { linkAvaliacao } = req.params;
            if (!linkAvaliacao) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Link de avaliação é obrigatório',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await capacitacaoService_1.default.getByLinkAvaliacao(linkAvaliacao);
            if (!capacitacao || !capacitacao.id) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            let idInscricao;
            if (req.body.email_participante && capacitacao.id) {
                const inscricoes = await capacitacaoService_1.default.listInscricoes(capacitacao.id);
                const inscricao = inscricoes.find(i => i.email === req.body.email_participante);
                if (inscricao && inscricao.id) {
                    idInscricao = inscricao.id;
                }
            }
            const avaliacao = await avaliacaoService_1.default.createAvaliacao(capacitacao.id, req.body, idInscricao);
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Avaliação submetida com sucesso. Obrigado pela sua participação!',
                data: avaliacao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async listMateriaisPublicos(req, res) {
        try {
            const { linkInscricao } = req.params;
            if (!linkInscricao) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Link de inscrição é obrigatório',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await prisma.capacitacao.findUnique({
                where: { link_inscricao: linkInscricao },
                include: {
                    qualificacao: true
                }
            });
            if (!capacitacao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const materiais = await prisma.capacitacao_material.findMany({
                where: {
                    id_qualificacao: capacitacao.id_qualificacao
                },
                orderBy: { created_at: 'desc' }
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: materiais,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            console.error('❌ [CapacitacaoPublicController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao listar materiais',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async verificarInscricao(req, res) {
        try {
            const { linkInscricao } = req.params;
            const { email } = req.body;
            if (!linkInscricao || !email) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Link de inscrição e email são obrigatórios',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const inscricao = await capacitacaoService_1.default.verificarInscricaoPorEmail(linkInscricao, email);
            if (!inscricao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Email não encontrado nas inscrições desta capacitação',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: inscricao,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            this.handleError(error, res);
        }
    }
    async downloadMaterialPublico(req, res) {
        try {
            const { linkInscricao, materialId } = req.params;
            if (!linkInscricao || !materialId) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Link de inscrição e ID do material são obrigatórios',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const materialIdNum = parseInt(materialId);
            if (isNaN(materialIdNum)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID do material inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const capacitacao = await prisma.capacitacao.findUnique({
                where: { link_inscricao: linkInscricao },
                include: {
                    qualificacao: true
                }
            });
            if (!capacitacao) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Capacitação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const material = await prisma.capacitacao_material.findFirst({
                where: {
                    id: materialIdNum,
                    id_qualificacao: capacitacao.id_qualificacao
                }
            });
            if (!material) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Material não encontrado ou não pertence a esta capacitação',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (!fs_1.default.existsSync(material.caminho_arquivo)) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Arquivo não encontrado no servidor',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            res.setHeader('Content-Disposition', `attachment; filename="${material.nome_original}"`);
            res.setHeader('Content-Type', material.tipo_mime);
            res.sendFile(path_1.default.resolve(material.caminho_arquivo));
        }
        catch (error) {
            console.error('❌ [CapacitacaoPublicController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao fazer download do material',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    handleError(error, res) {
        console.error('❌ [CapacitacaoPublicController] Error:', error);
        if (error instanceof Error && 'statusCode' in error) {
            const apiError = error;
            res.status(apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: apiError.message || 'Erro ao processar requisição',
                    code: apiError.code,
                    statusCode: apiError.statusCode || api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
        else {
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro interno do servidor',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
}
exports.capacitacaoPublicController = new CapacitacaoPublicController();
//# sourceMappingURL=capacitacaoPublicController.js.map