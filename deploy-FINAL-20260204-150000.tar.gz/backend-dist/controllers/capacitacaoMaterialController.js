"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadMaterial = exports.capacitacaoMaterialController = void 0;
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const client_1 = require("@prisma/client");
const api_1 = require("../types/api");
const prisma = new client_1.PrismaClient();
const UPLOAD_DIR = process.env.NODE_ENV === 'production'
    ? '/var/pinovara/shared/uploads/capacitacao/materiais'
    : '/Users/jorgepsendziuk/Documents/pinovara/uploads/capacitacao/materiais';
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        try {
            if (!fs_1.default.existsSync(UPLOAD_DIR)) {
                fs_1.default.mkdirSync(UPLOAD_DIR, { recursive: true, mode: 0o755 });
            }
            fs_1.default.accessSync(UPLOAD_DIR, fs_1.default.constants.W_OK);
            cb(null, UPLOAD_DIR);
        }
        catch (error) {
            console.error(`Erro ao configurar diretório de upload ${UPLOAD_DIR}:`, error);
            cb(new Error(`Sem permissão para escrever no diretório de upload. Contate o administrador do sistema.`), '');
        }
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path_1.default.extname(file.originalname));
    }
});
const fileFilter = (req, file, cb) => {
    const allowedTypes = [
        'application/pdf',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'video/mp4',
        'video/quicktime',
        'image/jpeg',
        'image/png'
    ];
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    }
    else {
        cb(new Error('Tipo de arquivo não permitido. Apenas PDF, PPT, DOC, vídeos e imagens são aceitos.'));
    }
};
const upload = (0, multer_1.default)({
    storage,
    fileFilter,
    limits: {
        fileSize: 100 * 1024 * 1024
    }
});
class CapacitacaoMaterialController {
    async uploadMaterial(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const idQualificacao = parseInt(req.params.id);
            if (isNaN(idQualificacao)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const file = req.file;
            if (!file) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'Nenhum arquivo foi enviado',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const qualificacao = await prisma.qualificacao.findUnique({
                where: { id: idQualificacao }
            });
            if (!qualificacao) {
                fs_1.default.unlinkSync(file.path);
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Qualificação não encontrada',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const material = await prisma.capacitacao_material.create({
                data: {
                    id_qualificacao: idQualificacao,
                    nome_arquivo: file.filename,
                    nome_original: file.originalname,
                    caminho_arquivo: path_1.default.join(UPLOAD_DIR, file.filename),
                    tamanho_bytes: file.size,
                    tipo_mime: file.mimetype,
                    descricao: req.body.descricao || null,
                    uploaded_by: req.user.id
                }
            });
            res.status(api_1.HttpStatus.CREATED).json({
                success: true,
                message: 'Material enviado com sucesso',
                data: material,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            console.error('❌ [CapacitacaoMaterialController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao fazer upload de material',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async listMateriais(req, res) {
        try {
            const idQualificacao = parseInt(req.params.id);
            if (isNaN(idQualificacao)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const materiais = await prisma.capacitacao_material.findMany({
                where: { id_qualificacao: idQualificacao },
                orderBy: { created_at: 'desc' }
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                data: materiais,
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            console.error('❌ [CapacitacaoMaterialController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao listar materiais',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async downloadMaterial(req, res) {
        try {
            const idQualificacao = parseInt(req.params.id);
            const materialId = parseInt(req.params.materialId);
            if (isNaN(idQualificacao) || isNaN(materialId)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const material = await prisma.capacitacao_material.findFirst({
                where: {
                    id: materialId,
                    id_qualificacao: idQualificacao
                }
            });
            if (!material) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Material não encontrado',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (!fs_1.default.existsSync(material.caminho_arquivo)) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Arquivo não encontrado no servidor',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            res.setHeader('Content-Disposition', `attachment; filename="${material.nome_original}"`);
            res.setHeader('Content-Type', material.tipo_mime);
            res.sendFile(path_1.default.resolve(material.caminho_arquivo));
        }
        catch (error) {
            console.error('❌ [CapacitacaoMaterialController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao fazer download do material',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
    async deleteMaterial(req, res) {
        try {
            if (!req.user?.id) {
                res.status(api_1.HttpStatus.UNAUTHORIZED).json({
                    success: false,
                    error: {
                        message: 'Usuário não autenticado',
                        statusCode: api_1.HttpStatus.UNAUTHORIZED
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const idQualificacao = parseInt(req.params.id);
            const materialId = parseInt(req.params.materialId);
            if (isNaN(idQualificacao) || isNaN(materialId)) {
                res.status(api_1.HttpStatus.BAD_REQUEST).json({
                    success: false,
                    error: {
                        message: 'ID inválido',
                        statusCode: api_1.HttpStatus.BAD_REQUEST
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            const material = await prisma.capacitacao_material.findFirst({
                where: {
                    id: materialId,
                    id_qualificacao: idQualificacao
                }
            });
            if (!material) {
                res.status(api_1.HttpStatus.NOT_FOUND).json({
                    success: false,
                    error: {
                        message: 'Material não encontrado',
                        statusCode: api_1.HttpStatus.NOT_FOUND
                    },
                    timestamp: new Date().toISOString()
                });
                return;
            }
            if (fs_1.default.existsSync(material.caminho_arquivo)) {
                fs_1.default.unlinkSync(material.caminho_arquivo);
            }
            await prisma.capacitacao_material.delete({
                where: { id: materialId }
            });
            res.status(api_1.HttpStatus.OK).json({
                success: true,
                message: 'Material excluído com sucesso',
                timestamp: new Date().toISOString()
            });
        }
        catch (error) {
            console.error('❌ [CapacitacaoMaterialController] Error:', error);
            res.status(api_1.HttpStatus.INTERNAL_SERVER_ERROR).json({
                success: false,
                error: {
                    message: 'Erro ao excluir material',
                    statusCode: api_1.HttpStatus.INTERNAL_SERVER_ERROR
                },
                timestamp: new Date().toISOString()
            });
        }
    }
}
exports.capacitacaoMaterialController = new CapacitacaoMaterialController();
exports.uploadMaterial = upload.single('arquivo');
//# sourceMappingURL=capacitacaoMaterialController.js.map