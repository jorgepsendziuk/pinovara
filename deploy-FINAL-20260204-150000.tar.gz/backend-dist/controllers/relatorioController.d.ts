import { Request, Response } from 'express';
export declare const relatorioController: {
    gerarPDF(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
};
//# sourceMappingURL=relatorioController.d.ts.map