import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
declare class CapacitacaoController {
    list(req: AuthRequest, res: Response): Promise<void>;
    getById(req: AuthRequest, res: Response): Promise<void>;
    create(req: AuthRequest, res: Response): Promise<void>;
    update(req: AuthRequest, res: Response): Promise<void>;
    delete(req: AuthRequest, res: Response): Promise<void>;
    listInscricoes(req: AuthRequest, res: Response): Promise<void>;
    createInscricao(req: AuthRequest, res: Response): Promise<void>;
    updateInscricao(req: AuthRequest, res: Response): Promise<void>;
    deleteInscricao(req: AuthRequest, res: Response): Promise<void>;
    listPresencas(req: AuthRequest, res: Response): Promise<void>;
    createPresenca(req: AuthRequest, res: Response): Promise<void>;
    updatePresenca(req: AuthRequest, res: Response): Promise<void>;
    deletePresenca(req: AuthRequest, res: Response): Promise<void>;
    addTecnico(req: AuthRequest, res: Response): Promise<void>;
    removeTecnico(req: AuthRequest, res: Response): Promise<void>;
    listTecnicos(req: AuthRequest, res: Response): Promise<void>;
    private handleError;
    updateValidacao(req: AuthRequest, res: Response): Promise<void>;
    getHistoricoValidacao(req: AuthRequest, res: Response): Promise<void>;
}
export declare const capacitacaoController: CapacitacaoController;
export {};
//# sourceMappingURL=capacitacaoController.d.ts.map