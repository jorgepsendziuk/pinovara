import { Request, Response } from 'express';
declare class CapacitacaoPublicController {
    getByLinkInscricao(req: Request, res: Response): Promise<void>;
    createInscricaoPublica(req: Request, res: Response): Promise<void>;
    getByLinkAvaliacao(req: Request, res: Response): Promise<void>;
    createAvaliacaoPublica(req: Request, res: Response): Promise<void>;
    listMateriaisPublicos(req: Request, res: Response): Promise<void>;
    verificarInscricao(req: Request, res: Response): Promise<void>;
    downloadMaterialPublico(req: Request, res: Response): Promise<void>;
    private handleError;
}
export declare const capacitacaoPublicController: CapacitacaoPublicController;
export {};
//# sourceMappingURL=capacitacaoPublicController.d.ts.map