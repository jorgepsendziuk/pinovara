import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
declare class CapacitacaoEvidenciaController {
    uploadEvidencia(req: AuthRequest, res: Response): Promise<void>;
    listEvidencias(req: AuthRequest, res: Response): Promise<void>;
    downloadEvidencia(req: AuthRequest, res: Response): Promise<void>;
    deleteEvidencia(req: AuthRequest, res: Response): Promise<void>;
}
export declare const capacitacaoEvidenciaController: CapacitacaoEvidenciaController;
export declare const uploadEvidencia: import("express").RequestHandler<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
export {};
//# sourceMappingURL=capacitacaoEvidenciaController.d.ts.map