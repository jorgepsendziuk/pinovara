export {};
//# sourceMappingURL=testar-api-edicao.d.ts.map