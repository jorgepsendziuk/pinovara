export {};
//# sourceMappingURL=testar-edicao-completa.d.ts.map