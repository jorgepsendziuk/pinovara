"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.enginesVersion = void 0;
exports.enginesVersion = require('./package.json').prisma.enginesVersion;
//# sourceMappingURL=index.js.map